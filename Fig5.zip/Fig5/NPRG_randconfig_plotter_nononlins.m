%% Plotter for config models mixtures of deg 3 and 4

rr4fig = figure;
hold on;


ax2 = subplot(3,2,1);
ax3 = subplot(3,2,2);


ax8 = subplot(3,2,3);
ax9 = subplot(3,2,4);

ax5 = subplot(3,2,5);
ax6 = subplot(3,2,6);


lw = 3;
fs = 20;

%% 100% deg 4

Ntrials = 10;
Tmax = 10000;
N = 2048;
numNeighbors = 4;

dt = 0.1;

Jc = 4/(2*sqrt(numNeighbors-1)-1); % mean-field estimate

J0 = 0.6*4/(2*sqrt(numNeighbors-1)-1);
fname =  ['RandomRegularGraphwithInhib_absorbing_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
avgPJ0p6Jc =load(fname);

J0 = 0.7*4/(2*sqrt(numNeighbors-1)-1);
fname =  ['RandomRegularGraphwithInhib_absorbing_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
avgPJ0p7Jc =load(fname);

J0 = 0.8*4/(2*sqrt(numNeighbors-1)-1);
fname =  ['RandomRegularGraphwithInhib_absorbing_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
avgPJ0p8Jc =load(fname);

J0 = 0.9*4/(2*sqrt(numNeighbors-1)-1);
fname =  ['RandomRegularGraphwithInhib_absorbing_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
avgPJ0p9Jc =load(fname);

J0 = 1.0*4/(2*sqrt(numNeighbors-1)-1);
fname =  ['RandomRegularGraphwithInhib_absorbing_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
avgPJ1p0Jc =load(fname);

J0 = 1.1*4/(2*sqrt(numNeighbors-1)-1);
fname =  ['RandomRegularGraphwithInhib_absorbing_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
avgPJ1p1Jc =load(fname);

%%


    lw = 3;
fs = 20;

cmap = parula(8);

subplot(3,2,1)
hold on;
loglog(ax2,(1:Tmax)*dt-dt,movmean(avgPJ0p6Jc(:,2),10,'endpoints','fill'),'LineWidth',lw,'color',cmap(1,:))
loglog(ax2,(1:Tmax)*dt-dt,movmean(avgPJ0p7Jc(:,2),10,'endpoints','fill'),'LineWidth',lw,'color',cmap(2,:))
loglog(ax2,(1:Tmax)*dt-dt,movmean(avgPJ0p8Jc(:,2),10,'endpoints','fill'),'LineWidth',lw,'color',cmap(3,:))
loglog(ax2,(1:Tmax)*dt-dt,movmean(avgPJ0p9Jc(:,2),10,'endpoints','fill'),'LineWidth',lw,'color',cmap(4,:))
loglog(ax2,(1:Tmax)*dt-dt,movmean(avgPJ1p0Jc(:,2),10,'endpoints','fill'),'LineWidth',lw,'color',cmap(5,:))
loglog(ax2,(1:Tmax)*dt-dt,movmean(avgPJ1p1Jc(:,2),10,'endpoints','fill'),'LineWidth',lw,'color',cmap(6,:))
ylim([1e-3, 2e0])
xlim([5e-1, 1e3])

    ax2.FontSize = fs;
ax2.XScale = 'log';
ax2.YScale = 'log';

    xlabel('$t$','interpreter','latex','fontsize',fs)
    ylabel('$\nu(t)$','interpreter','latex','fontsize',fs)

    axis square

        text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'A','FontSize',32)

%%

% mean-field
betaexp = 1.0;
zexp = 2.0;
nuexp = 0.5;

Jcest = 0.85*Jc;


subplot(3,2,2)
hold on;
loglog(abs(Jcest-0.6*Jc)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-0.6*Jc)^(-betaexp)*movmean(avgPJ0p6Jc(:,2),10,'endpoints','fill'),'LineWidth',lw,'color',cmap(1,:))
loglog(abs(Jcest-0.7*Jc)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-0.7*Jc)^(-betaexp)*movmean(avgPJ0p7Jc(:,2),10,'endpoints','fill'),'LineWidth',lw,'color',cmap(2,:))
loglog(abs(Jcest-0.8*Jc)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-0.8*Jc)^(-betaexp)*movmean(avgPJ0p8Jc(:,2),10,'endpoints','fill'),'LineWidth',lw,'color',cmap(3,:))
loglog(abs(Jcest-0.9*Jc)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-0.9*Jc)^(-betaexp)*movmean(avgPJ0p9Jc(:,2),10,'endpoints','fill'),'LineWidth',lw,'color',cmap(4,:))
loglog(abs(Jcest-1.0*Jc)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-1.0*Jc)^(-betaexp)*movmean(avgPJ1p0Jc(:,2),10,'endpoints','fill'),'LineWidth',lw,'color',cmap(5,:))
loglog(abs(Jcest-1.1*Jc)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-1.1*Jc)^(-betaexp)*movmean(avgPJ1p1Jc(:,2),10,'endpoints','fill'),'LineWidth',lw,'color',cmap(6,:))
ylim([1e-4, 5e1])
ax3.XScale = 'log';
ax3.YScale = 'log';

    ax3.FontSize = fs;

    xlabel('$|J_c-J|^{\nu_\ast z_\ast}t$','interpreter','latex','fontsize',fs)
    ylabel('$\nu(t)|J_c-J|^{-\beta_\ast}$','interpreter','latex','fontsize',fs)

    axis square

           text('Units', 'Normalized', 'Position', [0.05, 0.05], 'string', '$\nu_\ast z_\ast = 1$','FontSize',16,'Interpreter','latex')
        text('Units', 'Normalized', 'Position', [0.05, 0.15], 'string', '$\beta_\ast = 1$','FontSize',16,'Interpreter','latex')




    scalefy = 0.3;
scalefx = 1.0;
xs = 4:0.01:500;
loglog(scalefx*xs,scalefy*(1.79705 + 1.60276*exp(-0.741933*xs)./(1-exp(-0.741933*xs)))/1.8,'.','linewidth',5,'Color',[181/255,0,0])
xs = 100:0.01:500;
loglog(scalefx*xs/40,70*scalefy*(0.0447225*exp(-0.0168346*xs)./(1-exp(-0.0168346*xs))),'.','linewidth',5,'Color',[181/255,0,0])

    text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'B','FontSize',32)
%% 90% deg 3, 10% deg 4

Ntrials = 100;
Tmax = 10000;
N = 2000;
frac = 0.9;

J0 = 1.9;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ1p9 =load(fname);

J0 = 2.0;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ2p0 =load(fname);

J0 = 2.1;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ2p1 =load(fname);

J0 = 2.2;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ2p2 =load(fname);

J0 = 2.3;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ2p3 =load(fname);

J0 = 2.4;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ2p4 =load(fname);

J0 = 2.5;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ2p5 =load(fname);

%%

lw = 3;
fs = 20;

cmap = parula(9);


subplot(3,2,5)
loglog(ax5,(1:Tmax)*dt-dt,avgPJ1p9(:,2),'LineWidth',lw,'color',cmap(1,:))
hold on; loglog(ax5,(1:Tmax)*dt-dt,avgPJ2p0(:,2),'LineWidth',lw,'color',cmap(2,:))
hold on; loglog(ax5,(1:Tmax)*dt-dt,avgPJ2p1(:,2),'LineWidth',lw,'color',cmap(3,:))
hold on; loglog(ax5,(1:Tmax)*dt-dt,avgPJ2p2(:,2),'LineWidth',lw,'color',cmap(4,:))
hold on; loglog(ax5,(1:Tmax)*dt-dt,avgPJ2p3(:,2),'LineWidth',lw,'color',cmap(5,:))
hold on; loglog(ax5,(1:Tmax)*dt-dt,avgPJ2p4(:,2),'LineWidth',lw,'color',cmap(6,:))
hold on; loglog(ax5,(1:Tmax)*dt-dt,avgPJ2p5(:,2),'LineWidth',lw,'color',cmap(7,:))

    ax5.FontSize = fs;
ax5.YScale = 'log';
ax5.XScale = 'log';
    axis square
    xlabel('$t$','interpreter','latex','fontsize',fs)
    ylabel('$\nu(t)$','interpreter','latex','fontsize',fs)
ylim([1e-4, 3e0])
xlim([1e-1, 1e3])

    axis square

        text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'E','FontSize',32)

%%

% exponents
Jcest = 2.20;
betaexp = 0.65;
zexp = 1.9; 
nuexp = 1.0; % only the combination nu*z is determined by this collapse.


subplot(3,2,6)
hold on;
loglog(ax6,abs(Jcest-1.9)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-1.9)^(-betaexp)*avgPJ1p9(:,2),'LineWidth',lw,'color',cmap(1,:))
loglog(ax6,abs(Jcest-2.0)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-2.0)^(-betaexp)*avgPJ2p0(:,2),'LineWidth',lw,'color',cmap(2,:))
loglog(ax6,abs(Jcest-2.1)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-2.1)^(-betaexp)*avgPJ2p1(:,2),'LineWidth',lw,'color',cmap(3,:))
loglog(ax6,abs(Jcest-2.2)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-2.2)^(-betaexp)*avgPJ2p2(:,2),'LineWidth',lw,'color',cmap(4,:))
loglog(ax6,abs(Jcest-2.3)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-2.3)^(-betaexp)*avgPJ2p3(:,2),'LineWidth',lw,'color',cmap(5,:)) % too close to critical point
loglog(ax6,abs(Jcest-2.4)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-2.4)^(-betaexp)*avgPJ2p4(:,2),'LineWidth',lw,'color',cmap(6,:))
loglog(ax6,abs(Jcest-2.5)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-2.5)^(-betaexp)*avgPJ2p5(:,2),'LineWidth',lw,'color',cmap(7,:))
%ylim([1e-4, 1e2])

    ax6.FontSize = fs;
ax6.YScale = 'log';
ax6.XScale = 'log';
    axis square
    xlabel('$|J_c-J|^{\nu_\ast z_\ast}t$','interpreter','latex','fontsize',fs)
    ylabel('$\nu(t)|J_c-J|^{-\beta_\ast}$','interpreter','latex','fontsize',fs)
%
%

    axis square

           text('Units', 'Normalized', 'Position', [0.05, 0.05], 'string', '$\nu_\ast z_\ast = 1.9$','FontSize',16,'Interpreter','latex')
        text('Units', 'Normalized', 'Position', [0.05, 0.15], 'string', '$\beta_\ast = 0.65$','FontSize',16,'Interpreter','latex')

            scalefy = 0.3;
scalefx = 1.0;
xs = 4:0.01:500;
loglog(scalefx*xs,scalefy*(1.79705 + 1.60276*exp(-0.741933*xs)./(1-exp(-0.741933*xs)))/2.5,'.','linewidth',5,'Color',[181/255,0,0])
xs = 2:0.01:700;
loglog(xs,exp(-0.4262*xs -2.601),'.','linewidth',5,'Color',[181/255,0,0])

ylim([1e-4, 2e1])
xlim([1e-3, 1e2])

    text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'F','FontSize',32)

%% 80% deg 3, 20% deg 4

Ntrials = 100;
Tmax = 10000;
N = 2000;
frac = 0.8;

J0 = 1.8;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ1p8 =load(fname);

J0 = 1.9;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ1p9 =load(fname);

J0 = 2.0;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ2p0 =load(fname);

J0 = 2.1;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ2p1 =load(fname);

J0 = 2.2;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ2p2 =load(fname);

J0 = 2.3;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ2p3 =load(fname);

J0 = 2.4;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ2p4 =load(fname);

J0 = 2.5;
fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
avgPJ2p5 =load(fname);

%%

lw = 3;
fs = 20;

cmap = parula(10);


subplot(3,2,3)
hold on;
loglog(ax8,(1:Tmax)*dt-dt,avgPJ1p8(:,2),'LineWidth',lw,'color',cmap(1,:))
loglog(ax8,(1:Tmax)*dt-dt,avgPJ1p9(:,2),'LineWidth',lw,'color',cmap(2,:))
loglog(ax8,(1:Tmax)*dt-dt,avgPJ2p0(:,2),'LineWidth',lw,'color',cmap(3,:))
loglog(ax8,(1:Tmax)*dt-dt,avgPJ2p1(:,2),'LineWidth',lw,'color',cmap(4,:))
loglog(ax8,(1:Tmax)*dt-dt,avgPJ2p2(:,2),'LineWidth',lw,'color',cmap(5,:))
loglog(ax8,(1:Tmax)*dt-dt,avgPJ2p3(:,2),'LineWidth',lw,'color',cmap(6,:))
loglog(ax8,(1:Tmax)*dt-dt,avgPJ2p4(:,2),'LineWidth',lw,'color',cmap(7,:))
loglog(ax8,(1:Tmax)*dt-dt,avgPJ2p5(:,2),'LineWidth',lw,'color',cmap(8,:))

ax8.FontSize = fs;
ax8.YScale = 'log';
ax8.XScale = 'log';
    axis square
    xlabel('$t$','interpreter','latex','fontsize',fs)
    ylabel('$\nu(t)$','interpreter','latex','fontsize',fs)
ylim([1e-3, 2e0])
xlim([1e-1, 1e3])

    text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'C','FontSize',32)

%%

% mean-field
betaexp = 1.0;
zexp = 2.0;
nuexp = 0.5;


 Jcest = 1.98;


subplot(3,2,4)
hold on;
loglog(ax9,abs(Jcest-1.8)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-1.8)^(-betaexp)*avgPJ1p8(:,2),'LineWidth',lw,'color',cmap(1,:))
loglog(ax9,abs(Jcest-1.9)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-1.9)^(-betaexp)*avgPJ1p9(:,2),'LineWidth',lw,'color',cmap(2,:))
loglog(ax9,abs(Jcest-2.0)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-2.0)^(-betaexp)*avgPJ2p0(:,2),'LineWidth',lw,'color',cmap(3,:))
loglog(ax9,abs(Jcest-2.1)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-2.1)^(-betaexp)*avgPJ2p1(:,2),'LineWidth',lw,'color',cmap(4,:))
loglog(ax9,abs(Jcest-2.2)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-2.2)^(-betaexp)*avgPJ2p2(:,2),'LineWidth',lw,'color',cmap(5,:))
loglog(ax9,abs(Jcest-2.3)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-2.3)^(-betaexp)*avgPJ2p3(:,2),'LineWidth',lw,'color',cmap(6,:)) % too close to critical point
loglog(ax9,abs(Jcest-2.4)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-2.4)^(-betaexp)*avgPJ2p4(:,2),'LineWidth',lw,'color',cmap(7,:))
loglog(ax9,abs(Jcest-2.5)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jcest-2.5)^(-betaexp)*avgPJ2p5(:,2),'LineWidth',lw,'color',cmap(8,:))

    ax9.FontSize = fs;
ax9.YScale = 'log';
ax9.XScale = 'log';
    axis square
    xlabel('$|J_c-J|^{\nu_\ast z_\ast}t$','interpreter','latex','fontsize',fs)
    ylabel('$\nu(t)|J_c-J|^{-\beta_\ast}$','interpreter','latex','fontsize',fs)
 ylim([1e-3, 1e1])
 xlim([1e-3, 1e2])

        text('Units', 'Normalized', 'Position', [0.05, 0.05], 'string', '$\nu_\ast z_\ast = 1$','FontSize',16,'Interpreter','latex')
        text('Units', 'Normalized', 'Position', [0.05, 0.15], 'string', '$\beta_\ast = 1$','FontSize',16,'Interpreter','latex')


                    scalefy = 0.3;
scalefx = 1.0;
xs = 10:0.01:500;
loglog(scalefx*xs,scalefy*(1.79705 + 1.60276*exp(-0.741933*xs)./(1-exp(-0.741933*xs)))/2.5,'.','linewidth',5,'Color',[181/255,0,0])
xs = 5:0.01:100;
loglog(xs,exp(-0.2919*xs -0.4406),'.','linewidth',5,'Color',[181/255,0,0])

    text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'D','FontSize',32)

    ylim([1e-3, 2e2])
xlim([2e-3, 1e2])

        
%%

set(rr4fig,'units','normalized','position',[0 0 0.65 1.0])

