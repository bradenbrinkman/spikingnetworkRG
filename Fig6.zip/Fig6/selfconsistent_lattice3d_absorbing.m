tic
dt = 0.01;
Tmax = 1e5;

psi0 = 10;


d = 3;
J = 0.09; 


Eleak = 0; 

psi = zeros(1,Tmax);
sig2 = zeros(1,Tmax);

r0 = 0.5;

phi0 = max(0,1/(1+exp(-(psi0-log(1/r0-1))))-r0);

meanphi = zeros(1,Tmax);
meanphi(1) = phi0;

meanphiprime = zeros(1,Tmax);
meanphiprime(1) = exp(-(psi0))./(1+exp(-(psi0))).^2;

psi(1) = psi0; %psi0 + dt*(-psi0+Eleak + J*(2*d-1)*phi0);
sig2(1) = 0; %dt*J^2*(2*d+1)*phi0;

dz = 0.01;
z = -100:dz:100;

for t=2:Tmax

    meanphi(t) = trapz(exp(-z.^2/2).*max(0,1./(1+exp(-(psi(t-1)-log(1/r0-1)+sqrt(sig2(t-1))*z)))-r0))*dz/sqrt(2*pi);

    psi(t) = psi(t-1) + dt*(-psi(t-1) + Eleak + J*(2*d-1)*meanphi(t));

    sig2(t) = sig2(t-1) + dt*(-2*sig2(t-1) + J^2*(2*d+1)*meanphi(t));


end

toc

%%

writematrix([psi;meanphi]',['selfconPhi_lattice_d'  num2str(d) '_absorbing_J'  num2str(J) '.txt'],'Delimiter','tab');

