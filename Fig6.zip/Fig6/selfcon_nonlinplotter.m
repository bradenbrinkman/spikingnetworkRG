
Ntrials = 100;
Tmax = 1000;
N = 14^3;
d = 3;

cmap = parula(13);

%absorbing
J0 = 0.4125; 
selfconrateabsorbingd3J0p4125 = load('selfconPhi_lattice_d3_absorbing_J0.4125.txt');
fname =  ['Lattice_absorbing_nonlinsweep_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simabsorbingd3J0p4125= load(fname);

J0 = 0.825; 
selfconrateabsorbingd3J0p825 = load('selfconPhi_lattice_d3_absorbing_J0.825.txt');
fname =  ['Lattice_absorbing_nonlinsweep_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simabsorbingd3J0p825= load(fname);

J0 = 1.65; 
selfconrateabsorbingd3J1p65 = load('selfconPhi_lattice_d3_absorbing_J1.65.txt');
fname =  ['Lattice_absorbing_nonlinsweep_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(10*Tmax) '_J'  num2str(J0)   '.txt'];
simabsorbingd3J1p65= load(fname);

% Spontaneous networks
selfconrated3J0p5825 = load('selfconPhi_lattice_d3_sigmoid_J0.5825.txt');
simd3J0p5825= load('Lattice_nonlinsweep_d3_Ntrials100_N3375_Tmax1000_J0.5825_Eleak-1.3313.txt');

selfconrated3J1p165 = load('selfconPhi_lattice_d3_sigmoid_J1.165.txt');
simd3J1p165= load('Lattice_nonlinsweep_d3_Ntrials100_N3375_Tmax1000_J1.165_Eleak-2.7875.txt');

simd3J1p18 = load('Lattice_nonlinsweep_d3_Ntrials100_N3375_Tmax1000_J1.18_Eleak-1.7246.txt'); % to check slope

simd3J1p5= load('Lattice_nonlinsweep_d3_Ntrials100_N3375_Tmax1000_J1.5_Eleak-3.625.txt'); % to check slope

simd3J2p0= load('Lattice_nonlinsweep_d3_Ntrials100_N3375_Tmax1000_J2_Eleak-4.875.txt'); % to check slope

selfconrated3J2p33 = load('selfconPhi_lattice_d3_sigmoid_J2.33_Eleak-4.9698.txt');
simd3J2p33= load('Lattice_nonlinsweep_d3_Ntrials100_N3375_Tmax1000_J2.33_Eleak-5.7.txt');

% spontaneous network numerical solution for collapse (panels D and E)
load('selfconsistent_collapsedata');

%%
x = 0:0.01:10;
phi = 1./(1+exp(-x));

fs = 28; %20
fslabel = 48; %32
lw = 3;

% +0*fliplr([0.6350 0.0780 0.5840])

figure;
ax1 = axes;

plot(ax1,simabsorbingd3J0p4125(2:end,1),simabsorbingd3J0p4125(2:end,2),'LineWidth',3*lw,'Color',cmap(2,:))
hold on;
plot(ax1,simabsorbingd3J0p825(2:end,1),simabsorbingd3J0p825(2:end,2),'LineWidth',3*lw,'Color',cmap(4,:))
plot(ax1,simabsorbingd3J1p65(2:end,1),simabsorbingd3J1p65(2:end,2),'LineWidth',3*lw,'Color',cmap(6,:))
plot(ax1,selfconrateabsorbingd3J0p4125(:,1),selfconrateabsorbingd3J0p4125(:,2),'-.','LineWidth',lw,'Color',cmap(11,:))
plot(ax1,x,phi-0.5,'k--','LineWidth',lw)
plot(ax1,selfconrateabsorbingd3J0p825(:,1),selfconrateabsorbingd3J0p825(:,2),'-.','LineWidth',lw,'Color',0.9*cmap(11,:))
plot(ax1,selfconrateabsorbingd3J1p65(:,1),selfconrateabsorbingd3J1p65(:,2),'-.','LineWidth',lw,'Color',0.8*cmap(11,:))
xlim([0,10])
ylim([0,0.6])
xlabel('$\psi(t)$','interpreter','latex')
ylabel('$\nu(t)$','interpreter','latex')
%text(0.5,0.55,'A','FontSize',32)
text('Units', 'Normalized', 'Position', [0.1, 0.9], 'string', 'A','FontSize',fslabel)
ax1.FontSize = fs;
axis square
lgd1 = legend('Sim. $J=J_c/2$','Sim. $J=J_c$','Sim. $J=2J_c$','self-con.','mean-field','location','southeast','FontSize',fs);
lgd1.Interpreter = 'latex';
legend('boxoff')

figure;
ax4 = axes;

plot(ax4,simd3J0p5825(1:end-1,1),simd3J0p5825(1:end-1,2),'LineWidth',3*lw,'Color',cmap(2,:))
hold on;
plot(ax4,simd3J1p165(1:end-1,1),simd3J1p165(1:end-1,2),'LineWidth',3*lw,'Color',cmap(4,:))
plot(ax4,simd3J2p33(1:end-1,1),simd3J2p33(1:end-1,2),'LineWidth',3*lw,'Color',cmap(6,:))
%plot(simd3J2p33(1:end-1,1),simd3J2p33(1:end-1,2),'s','MarkerSize',10,'Color',cmap(6,:))
plot(ax4,selfconrated3J0p5825(:,1),selfconrated3J0p5825(:,2),'-.','LineWidth',lw,'Color',cmap(11,:))
plot(ax4,x,phi,'k--','LineWidth',lw)
plot(ax4,selfconrated3J1p165(:,1),selfconrated3J1p165(:,2),'-.','LineWidth',lw,'Color',0.9*cmap(11,:))
plot(ax4,selfconrated3J2p33(:,1),selfconrated3J2p33(:,2),'-.','LineWidth',lw,'Color',0.8*cmap(11,:))
xlabel('$\psi(t)$','interpreter','latex')
ylabel('$\nu(t)$','interpreter','latex')
ylim([0,1.2])
text('Units', 'Normalized', 'Position', [0.1, 0.9], 'string', 'C','FontSize',fslabel)
ax4.FontSize = fs;
axis square
% lgd = legend('Sim. $J=J_c/2$','Sim. $J=J_c$','Sim. $J=2J_c$','RG','mean-field','location','northwest','FontSize',20);
% lgd.Interpreter = 'latex';
%legend('boxoff')


%%

jj = 9; %1:numel(J0vals) %ceil(numel(J0vals)/2)

J0 = J0vals(jj);

fig5 = figure;
ax5 = axes;
%  axes('XScale', 'log', 'YScale', 'log')
hold on;

for ee=1:numel(Eleakdiffs)


    plot(ax5,(1:Tmax)*dt-dt,meanphiP(:,jj,ee),'linewidth',lw,'color',cmap(ee,:))
    plot(ax5,(1:Tmax)*dt-dt,meanphiM(:,jj,ee),'linewidth',lw,'color',cmap(ee,:))

end
    ax5.FontSize = fs;
    axis square
    xlabel('$t$','interpreter','latex','fontsize',fs)
    ylabel('$\nu_\pm(t)$','interpreter','latex','fontsize',fs)
xlim([0, 1000])
plot(ax5,(1:Tmax)*dt-dt,0.367926*ones(1,Tmax),'k--')
text('Units', 'Normalized', 'Position', [0.1, 0.9], 'string', 'D','FontSize',fslabel)

    dt = 0.1;


    alpha = 0.5;
    thetac = 0.0;



    J0 = J0vals(jj);

    fig6 = figure;
    ax6 = axes;
    %   axes('XScale', 'log', 'YScale', 'log')
    hold on;

    for ee=1:numel(Eleakdiffs)


        Eleak = Eleakvals(jj,ee);

        plot(ax6,(Eleak-(-0.683457-J0*5*0.367926))*((1:Tmax)*dt-dt).^(1+alpha),(squeeze(meanphiP(:,jj,ee)-meanphiM(:,jj,ee))).*((1:Tmax)'*dt-dt).^alpha,'linewidth',lw,'color',cmap(ee,:))


    end
            axis square
        xlabel('$(\mathcal E - \mathcal E_c(J_c))t^{3/2}$','Interpreter','latex','FontSize',20)
        ylabel('$(\nu_+(t) - \nu_-(t))t^{1/2}$','Interpreter','latex','FontSize',20)
    ax6.FontSize = fs;
    xlim([-1000 1000])
    text('Units', 'Normalized', 'Position', [0.1, 0.9], 'string', 'E','FontSize',fslabel)


%% Absorbing collapse

selfconJ0p0 = load('selfconPhi_lattice_d3_absorbing_J0.txt');
selfconJ0p25 = load('selfconPhi_lattice_d3_absorbing_J0.25.txt');
selfconJ0p5 = load('selfconPhi_lattice_d3_absorbing_J0.5.txt');
selfconJ0p75 = load('selfconPhi_lattice_d3_absorbing_J0.75.txt');
selfconJ1p0 = load('selfconPhi_lattice_d3_absorbing_J1.txt');
selfconJ1p25 = load('selfconPhi_lattice_d3_absorbing_J1.25.txt');
selfconJ1p5 = load('selfconPhi_lattice_d3_absorbing_J1.5.txt');

selfconJ0p1 = load('selfconPhi_lattice_d3_absorbing_J0.1.txt');
selfconJ0p2 = load('selfconPhi_lattice_d3_absorbing_J0.2.txt');
selfconJ0p3 = load('selfconPhi_lattice_d3_absorbing_J0.3.txt');
selfconJ0p4 = load('selfconPhi_lattice_d3_absorbing_J0.4.txt');
selfconJ0p6 = load('selfconPhi_lattice_d3_absorbing_J0.6.txt');
selfconJ0p7 = load('selfconPhi_lattice_d3_absorbing_J0.7.txt');
selfconJ0p8 = load('selfconPhi_lattice_d3_absorbing_J0.8.txt');
selfconJ0p9 = load('selfconPhi_lattice_d3_absorbing_J0.9.txt');

selfconJ0p01 = load('selfconPhi_lattice_d3_absorbing_J0.01.txt');
selfconJ0p02 = load('selfconPhi_lattice_d3_absorbing_J0.02.txt');
selfconJ0p03 = load('selfconPhi_lattice_d3_absorbing_J0.03.txt');
selfconJ0p04 = load('selfconPhi_lattice_d3_absorbing_J0.04.txt');
selfconJ0p05 = load('selfconPhi_lattice_d3_absorbing_J0.05.txt');
selfconJ0p06 = load('selfconPhi_lattice_d3_absorbing_J0.06.txt');
selfconJ0p07 = load('selfconPhi_lattice_d3_absorbing_J0.07.txt');
selfconJ0p08 = load('selfconPhi_lattice_d3_absorbing_J0.08.txt');
selfconJ0p09 = load('selfconPhi_lattice_d3_absorbing_J0.09.txt');

dt = 0.01;
Tmax = 1e5;

%%


figure; 
ax2  = axes;
plot(ax2,(1:Tmax)*dt-dt,selfconJ0p0(:,2),'linewidth',lw,'color',cmap(4,:))
hold on;
plot(ax2,(1:Tmax)*dt-dt,selfconJ0p1(:,2),'linewidth',lw,'color',cmap(5,:))
plot(ax2,(1:Tmax)*dt-dt,selfconJ0p2(:,2),'linewidth',lw,'color',cmap(6,:))
plot(ax2,(1:Tmax)*dt-dt,selfconJ0p3(:,2),'linewidth',lw,'color',cmap(7,:))
plot(ax2,(1:Tmax)*dt-dt,selfconJ0p4(:,2),'linewidth',lw,'color',cmap(8,:))
plot(ax2,(1:Tmax)*dt-dt,selfconJ0p5(:,2),'linewidth',lw,'color',cmap(9,:))
plot(ax2,(1:Tmax)*dt-dt,selfconJ0p6(:,2),'linewidth',lw,'color',cmap(10,:))
set(gca,'XScale','log','YScale','log')
text('Units', 'Normalized', 'Position', [0.1, 0.9], 'string', 'B','FontSize',fslabel)
xlim([1.0 1e3])
ylim([1e-4, 10.0])
        xlabel('$t$','Interpreter','latex','FontSize',20)
        ylabel('$\nu(t)$','Interpreter','latex','FontSize',20)
ax2.FontSize = fs;
axis square

%% All in one subfigure


fig1to6 = figure;
axs1 = subplot(2,3,1,'parent',fig1to6);
axs2 = subplot(2,3,2,'parent',fig1to6);
%axs3 = subplot(2,3,3,'parent',fig1to6);
axs4 = subplot(2,3,4,'parent',fig1to6);
axs5 = subplot(2,3,5,'parent',fig1to6);
axs6 = subplot(2,3,6,'parent',fig1to6);

axcp1 = copyobj([ax1,lgd1], fig1to6);
set(axcp1,'Position',get(axs1,'position'));
lgdtmp = findobj(gcf, 'Type', 'Legend');
lgdtmp.Location = 'southeast';
delete(axs1);

axcp2 = copyobj(ax2, fig1to6);
set(axcp2,'Position',get(axs2,'position'));
delete(axs2);

% axcp3 = copyobj(ax3, fig1to6);
% set(axcp3,'Position',get(axs3,'position'));
% delete(axs3);

axcp4 = copyobj(ax4, fig1to6);
set(axcp4,'Position',get(axs4,'position'));
delete(axs4);

%axcp5 = copyobj([ax5,lgd5], fig1to6);
axcp5 = copyobj(ax5, fig1to6);
set(axcp5,'Position',get(axs5,'position'));
% lgdtmp = findobj(gcf, 'Type', 'Legend');
% lgdtmp.Location = 'southeast';
delete(axs5);

axcp6 = copyobj(ax6, fig1to6);
set(axcp6,'Position',get(axs6,'position'));
delete(axs6);

set(fig1to6,'units','normalized','position',[0 0 0.5 0.5])
%set(fig1to6,'units','inches','position',[0 0 9.0 9.0])

%% collapse attempts that don't work well.

% the predicted solution nu(t) ~ (const*exp(-t*(1-5*J/8)) + const*J*exp(-(1-5*J/8)*t) + const*J^2)/(8-5*J)^2,
% so I tried various ways of combining terms, but none really give a clean collapse. And there is no power-law decay in time anyways.

%%
figure; plot((1:Tmax)*dt-dt,selfconJ0p0(:,2))
hold on;
plot((1:Tmax)*dt-dt,selfconJ0p25(:,2))
plot((1:Tmax)*dt-dt,selfconJ0p5(:,2))
plot((1:Tmax)*dt-dt,selfconJ0p75(:,2))
plot((1:Tmax)*dt-dt,selfconJ1p0(:,2))
plot((1:Tmax)*dt-dt,selfconJ1p25(:,2))
plot((1:Tmax)*dt-dt,selfconJ1p5(:,2))
set(gca,'XScale','log','YScale','log')
ylim([1e-3, 1.0])

%%

figure; plot([0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1],[selfconJ0p01(end,2),selfconJ0p02(end,2),selfconJ0p03(end,2),selfconJ0p04(end,2),selfconJ0p05(end,2),selfconJ0p06(end,2),selfconJ0p07(end,2),selfconJ0p08(end,2),selfconJ0p09(end,2),selfconJ0p1(end,2)])

hold on; plot(0:0.01:0.1,(0:0.01:0.1).^2/25,'-')
set(gca,'XScale','log','YScale','log')
% 

figure; plot([0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1],[selfconJ0p01(end,2),selfconJ0p02(end,2),selfconJ0p03(end,2),selfconJ0p04(end,2),selfconJ0p05(end,2),selfconJ0p06(end,2),selfconJ0p07(end,2),selfconJ0p08(end,2),selfconJ0p09(end,2),selfconJ0p1(end,2)]./([0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1].^2),'o-')

%set(gca,'XScale','log','YScale','log')

%%

a1 = 0.0;
a2 = 2.052;

figure; plot(0.01^a1*((1:Tmax)*dt-dt),(8-5*0.01)^2*selfconJ0p01(:,2)/0.01^a2)
hold on;
plot(0.02^a1*((1:Tmax)*dt-dt),(8-5*0.02)^2*selfconJ0p02(:,2)/0.02^a2)
plot(0.03^a1*((1:Tmax)*dt-dt),(8-5*0.03)^2*selfconJ0p03(:,2)/0.03^a2)
plot(0.04^a1*((1:Tmax)*dt-dt),(8-5*0.04)^2*selfconJ0p04(:,2)/0.04^a2)
plot(0.05^a1*((1:Tmax)*dt-dt),(8-5*0.05)^2*selfconJ0p05(:,2)/0.05^a2)
plot(0.06^a1*((1:Tmax)*dt-dt),(8-5*0.06)^2*selfconJ0p06(:,2)/0.06^a2)
%plot(0.07^a1*((1:Tmax)*dt-dt),(8-5*0.07)^2*selfconJ0p07(:,2)/0.07^a2)
set(gca,'XScale','log','YScale','log')
%set(gca,'XScale','log')

%% t*(1+J)

a2 = 1.0;

figure; plot(((1:Tmax)*dt-dt)*(1-0.01*5/8),(8-5*0.01)^2*selfconJ0p01(:,2)/0.01^a2)
hold on;
plot(((1:Tmax)*dt-dt)*(1-0.02*5/8),(8-5*0.02)^2*selfconJ0p02(:,2)/0.02^a2)
plot(((1:Tmax)*dt-dt)*(1-0.03*5/8),(8-5*0.03)^2*selfconJ0p03(:,2)/0.03^a2)
plot(((1:Tmax)*dt-dt)*(1-0.04*5/8),(8-5*0.04)^2*selfconJ0p04(:,2)/0.04^a2)
plot(((1:Tmax)*dt-dt)*(1-0.05*5/8),(8-5*0.05)^2*selfconJ0p05(:,2)/0.05^a2)
plot(((1:Tmax)*dt-dt)*(1-0.06*5/8),(8-5*0.06)^2*selfconJ0p06(:,2)/0.06^a2)
%plot(((1:Tmax)*dt-dt)*(1+0.07*5/8),(8-5*0.07)^2*selfconJ0p07(:,2)/0.07^a2)
set(gca,'XScale','log','YScale','log')
%set(gca,'XScale','log')

a2 = 0.0;

figure; plot(((1:Tmax)*dt-dt)*(1-0.01*5/8),(8-5*0.01)^2*selfconJ0p01(:,2)/0.01^a2)
hold on;
plot(((1:Tmax)*dt-dt)*(1-0.02*5/8),(8-5*0.02)^2*selfconJ0p02(:,2)/0.02^a2)
plot(((1:Tmax)*dt-dt)*(1-0.03*5/8),(8-5*0.03)^2*selfconJ0p03(:,2)/0.03^a2)
plot(((1:Tmax)*dt-dt)*(1-0.04*5/8),(8-5*0.04)^2*selfconJ0p04(:,2)/0.04^a2)
plot(((1:Tmax)*dt-dt)*(1-0.05*5/8),(8-5*0.05)^2*selfconJ0p05(:,2)/0.05^a2)
plot(((1:Tmax)*dt-dt)*(1-0.06*5/8),(8-5*0.06)^2*selfconJ0p06(:,2)/0.06^a2)
%plot(((1:Tmax)*dt-dt)*(1+0.07*5/8),(8-5*0.07)^2*selfconJ0p07(:,2)/0.07^a2)
set(gca,'XScale','log','YScale','log')
%set(gca,'XScale','log')

%%

a2 = 2.0;

figure; plot(((1:Tmax)*dt-dt)*(1-0.01*5/8)-2*log(0.01),(8-5*0.01)^2*selfconJ0p01(:,2)/0.01^a2)
hold on;
plot(((1:Tmax)*dt-dt)*(1-0.02*5/8)-2*log(0.02),(8-5*0.02)^2*selfconJ0p02(:,2)/0.02^a2)
plot(((1:Tmax)*dt-dt)*(1-0.03*5/8)-2*log(0.03),(8-5*0.03)^2*selfconJ0p03(:,2)/0.03^a2)
plot(((1:Tmax)*dt-dt)*(1-0.04*5/8)-2*log(0.04),(8-5*0.04)^2*selfconJ0p04(:,2)/0.04^a2)
plot(((1:Tmax)*dt-dt)*(1-0.05*5/8)-2*log(0.05),(8-5*0.05)^2*selfconJ0p05(:,2)/0.05^a2)
%plot(((1:Tmax)*dt-dt)*(1-0.06*5/8)-2*log(0.06),(8-5*0.06)^2*selfconJ0p06(:,2)/0.06^a2)
%plot(((1:Tmax)*dt-dt)*(1+0.07*5/8)-2*log(0.07),(8-5*0.07)^2*selfconJ0p07(:,2)/0.07^a2)
%set(gca,'XScale','log','YScale','log')
set(gca,'YScale','log')

%%

figure; plot(((1:Tmax)*dt-dt)*(1-0.01*5/8),(8-5*0.01)^2*(selfconJ0p01(:,2)-selfconJ0p01(end,2))/0.01)
hold on;
plot(((1:Tmax)*dt-dt)*(1-0.02*5/8),(8-5*0.02)^2*(selfconJ0p02(:,2)-selfconJ0p02(end,2))/0.02)
plot(((1:Tmax)*dt-dt)*(1-0.03*5/8),(8-5*0.03)^2*(selfconJ0p03(:,2)-selfconJ0p03(end,2))/0.03)
plot(((1:Tmax)*dt-dt)*(1-0.04*5/8),(8-5*0.04)^2*(selfconJ0p04(:,2)-selfconJ0p04(end,2))/0.04)
plot(((1:Tmax)*dt-dt)*(1-0.05*5/8),(8-5*0.05)^2*(selfconJ0p05(:,2)-selfconJ0p05(end,2))/0.05)
plot(((1:Tmax)*dt-dt)*(1-0.06*5/8),(8-5*0.06)^2*(selfconJ0p06(:,2)-selfconJ0p06(end,2))/0.06)
%plot(((1:Tmax)*dt-dt)*(1+0.07*5/8),(8-5*0.07)^2*(selfconJ0p07(:,2)-selfconJ0p07(end,2))/0.07)
set(gca,'XScale','log','YScale','log')
%set(gca,'XScale','log')


%%

figure; plot([0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0],[selfconJ0p1(end,2),selfconJ0p2(end,2),selfconJ0p3(end,2),selfconJ0p4(end,2),selfconJ0p5(end,2),selfconJ0p6(end,2),selfconJ0p7(end,2),selfconJ0p8(end,2),selfconJ0p9(end,2),selfconJ1p0(end,2)])

hold on; plot(0:0.1:1,(0:0.1:1).^2.0/30,'-')
set(gca,'XScale','log','YScale','log')

% 

figure; plot([0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0],[selfconJ0p1(end,2),selfconJ0p2(end,2),selfconJ0p3(end,2),selfconJ0p4(end,2),selfconJ0p5(end,2),selfconJ0p6(end,2),selfconJ0p7(end,2),selfconJ0p8(end,2),selfconJ0p9(end,2),selfconJ1p0(end,2)]./([0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0].^2),'o-')

%set(gca,'XScale','log','YScale','log')
% 

%%

figure; plot([0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0],[selfconJ0p01(end,2),selfconJ0p02(end,2),selfconJ0p03(end,2),selfconJ0p04(end,2),selfconJ0p05(end,2),selfconJ0p06(end,2),selfconJ0p07(end,2),selfconJ0p08(end,2),selfconJ0p09(end,2), selfconJ0p1(end,2),selfconJ0p2(end,2),selfconJ0p3(end,2),selfconJ0p4(end,2),selfconJ0p5(end,2),selfconJ0p6(end,2),selfconJ0p7(end,2),selfconJ0p8(end,2),selfconJ0p9(end,2),selfconJ1p0(end,2)],'o-')
%hold on; plot(0:0.01:1,(0:0.01:1).^2.052/30,'-')
hold on; plot([0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0],7/64/pi*[0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0].^2,'o-')
set(gca,'XScale','log','YScale','log')

figure; plot([0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0],[selfconJ0p01(end,2),selfconJ0p02(end,2),selfconJ0p03(end,2),selfconJ0p04(end,2),selfconJ0p05(end,2),selfconJ0p06(end,2),selfconJ0p07(end,2),selfconJ0p08(end,2),selfconJ0p09(end,2), selfconJ0p1(end,2),selfconJ0p2(end,2),selfconJ0p3(end,2),selfconJ0p4(end,2),selfconJ0p5(end,2),selfconJ0p6(end,2),selfconJ0p7(end,2),selfconJ0p8(end,2),selfconJ0p9(end,2),selfconJ1p0(end,2)]./([0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0].^2.052),'o-')
set(gca,'XScale','log','YScale','log')

%%

figure; plot(((1:Tmax)*dt-dt),selfconJ0p1(:,2)/0.1^2)
hold on;
plot(((1:Tmax)*dt-dt),selfconJ0p2(:,2)/0.2^2)
plot(((1:Tmax)*dt-dt),selfconJ0p3(:,2)/0.3^2)
plot(((1:Tmax)*dt-dt),selfconJ0p4(:,2)/0.4^2)
plot(((1:Tmax)*dt-dt),selfconJ0p5(:,2)/0.5^2)
plot(((1:Tmax)*dt-dt),selfconJ0p6(:,2)/0.6^2)
plot(((1:Tmax)*dt-dt),selfconJ0p7(:,2)/0.7^2)
set(gca,'XScale','log','YScale','log')

%%

figure; plot([0.25 0.5 0.75 1.0 1.25 1.5],[selfconJ0p25(end,2),selfconJ0p5(end,2),selfconJ0p75(end,2),selfconJ1p0(end,2),selfconJ1p25(end,2),selfconJ1p5(end,2)])

set(gca,'XScale','log','YScale','log')

figure; plot([0.25 0.5 0.75 1.0 1.25 1.5],[selfconJ0p25(end,2),selfconJ0p5(end,2),selfconJ0p75(end,2),selfconJ1p0(end,2),selfconJ1p25(end,2),selfconJ1p5(end,2)]./[0.25 0.5 0.75 1.0 1.25 1.5])

set(gca,'XScale','log','YScale','log')

%%

figure; plot(0.25*((1:Tmax)*dt-dt),selfconJ0p25(:,2)/0.25^2)
hold on;
plot(0.5*((1:Tmax)*dt-dt),selfconJ0p5(:,2)/0.5^2)
plot(0.75*((1:Tmax)*dt-dt),selfconJ0p75(:,2)/0.75^2)
plot(1.0*((1:Tmax)*dt-dt),selfconJ1p0(:,2)/1.0^2)
plot(1.25*((1:Tmax)*dt-dt),selfconJ1p25(:,2)/1.25^2)
%plot(1.5*((1:Tmax)*dt-dt),selfconJ1p5(:,2)/1.5^2)
set(gca,'XScale','log','YScale','log')



