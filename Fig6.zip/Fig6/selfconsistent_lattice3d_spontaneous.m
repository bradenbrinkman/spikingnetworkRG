tic
dt = 0.01;
Tmax = 5e5; %1e6;

psi0 = 10;

phi0 = 1/(1+exp(-psi0));


d = 3;
J = 2.33; 


Eleak = -0.683457-J*5*0.367926; %-J*(2*d-1)*0.5; %-J*(2*d-1)*phi0;


% positive IC
psiP = zeros(1,Tmax);
sig2P = zeros(1,Tmax);

meanphiP = zeros(1,Tmax);
meanphiP(1) = 1/(1+exp(-(psi0)));

meanphiprimeP = zeros(1,Tmax);
meanphiprimeP(1) = exp(-(psi0))./(1+exp(-(psi0))).^2;

psiP(1) = psi0 + dt*(-psi0+Eleak + J*(2*d-1)*phi0);
sig2P(1) = dt*J^2*(2*d+1)*phi0;

% negative IC
psiM = zeros(1,Tmax);
sig2M = zeros(1,Tmax);

meanphiM = zeros(1,Tmax);
meanphiM(1) = 1/(1+exp(-(-psi0)));

meanphiprimeM = zeros(1,Tmax);
meanphiprimeM(1) = exp(-(-psi0))./(1+exp(-(-psi0))).^2;

psiM(1) = -psi0 + dt*(psi0+Eleak + J*(2*d-1)*phi0);
sig2M(1) = dt*J^2*(2*d+1)*phi0;

dz = 0.01;
z = -100:dz:100;

for t=2:Tmax

    meanphiP(t) = trapz(exp(-z.^2/2)./(1+exp(-(psiP(t-1)+sqrt(sig2P(t-1))*z))))*dz/sqrt(2*pi);

    meanphiprimeP(t) = trapz(exp(-z.^2/2).*exp(-(psiP(t-1)+sqrt(sig2P(t-1))*z))./(1+exp(-(psiP(t-1)+sqrt(sig2P(t-1))*z))).^2)*dz/sqrt(2*pi);

    psiP(t) = psiP(t-1) + dt*(-psiP(t-1) + Eleak + J*(2*d-1)*meanphiP(t));

    sig2P(t) = sig2P(t-1) + dt*(-2*sig2P(t-1) + J^2*(2*d+1)*meanphiP(t));


        meanphiM(t) = trapz(exp(-z.^2/2)./(1+exp(-(psiM(t-1)+sqrt(sig2M(t-1))*z))))*dz/sqrt(2*pi);

    meanphiprimeM(t) = trapz(exp(-z.^2/2).*exp(-(psiM(t-1)+sqrt(sig2M(t-1))*z))./(1+exp(-(psiM(t-1)+sqrt(sig2M(t-1))*z))).^2)*dz/sqrt(2*pi);

    psiM(t) = psiM(t-1) + dt*(-psiM(t-1) + Eleak + J*(2*d-1)*meanphiM(t));

    sig2M(t) = sig2M(t-1) + dt*(-2*sig2M(t-1) + J^2*(2*d+1)*meanphiM(t));


end

toc

%%

psiT = [psiM, fliplr(psiP)];
meanphiT = [meanphiM, fliplr(meanphiP)];

writematrix([psiT;meanphiT]',['selfconPhi_lattice_d'  num2str(d) '_sigmoid_J'  num2str(J) '_Eleak' num2str(Eleak) '.txt'],'Delimiter','tab');
