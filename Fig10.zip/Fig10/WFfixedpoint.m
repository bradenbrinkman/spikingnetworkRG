function dydt = WFfixedpoint(t,y,d)
  
dydt = zeros(2,1);
  
dydt(1) = y(1) + 0.5*y(2)./(1-y(1));
  
dydt(2) = 0.5*(4-d)*y(2) + 1.5*y(2).^2./(1-y(1)).^2;

end