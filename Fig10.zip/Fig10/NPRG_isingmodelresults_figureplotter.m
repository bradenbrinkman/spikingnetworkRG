%% NPRG Ising model results plot

isingfig = figure;
hold on;

%ax1 = subplot(2,4,1);
ax2 = subplot(2,4,2);
ax3 = subplot(2,4,3);
ax4 = subplot(2,4,4);
ax5 = subplot(2,4,5);
ax6 = subplot(2,4,6);
ax7 = subplot(2,4,7);
ax8 = subplot(2,4,8);

lw = 3;
fs = 20;

%% First subplot contains nothing (will put schematic there)

%% Phase planes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% spontaneous network

% d > 4

d = 5;

x = -0.05:0.05:1;
y = -0.5:0.05:0.05;

[X,Y] = meshgrid(x,y);

g11dot = X + 0.5*Y./(1-X);
g13dot = 0.5*(4-d)*Y + 1.5*Y.^2./(1-X).^2;


mag = sqrt(g11dot.^2+g13dot.^2);

%% compute solutions on stable manifold

% fine tune initial values to get flow to fixed point along stable manifold

[dgtr4sol1t,dgtr4sol1y] = ode45(@(t,y) WFfixedpoint(t,y,d),[0 12], [0.132175,-0.5]);

arrow2startidx = floor(numel(dgtr4sol1y(:,1))*0.3);

fs = 20;
arrowSize = 15;

subplot(2,4,2)
hold on;


quiver(ax2,X,Y,g11dot./mag,g13dot./mag)

hold on;

plot(ax2,x,0*x,'LineWidth',3,'Color',[181/255 0 0])
plot(ax2,dgtr4sol1y(:,1),dgtr4sol1y(:,2),'LineWidth',3,'Color',[0 0 181/255])

arrow1 = annotation('arrow','Color',[181/255 0 0],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow1.Parent = ax2; 
arrow1.Position = [0, 0, 0.2, 0]; % [x_start, y_start, delta_x, delta_y] ;

arrow2 = annotation('arrow','Color',[0 0 181/255],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow2.Parent = ax2; 
arrow2.Position = [dgtr4sol1y(arrow2startidx,1)-0.005, dgtr4sol1y(arrow2startidx,2), dgtr4sol1y(arrow2startidx+1,1)-dgtr4sol1y(arrow2startidx,1), dgtr4sol1y(arrow2startidx+2,2)-dgtr4sol1y(arrow2startidx,2)];

plot(ax2,0,0,'o','MarkerSize',15,'MarkerFaceColor','k','MarkerEdgeColor','k')


xlim([-0.05 1]);
ylim([-0.5, 0.05]);
xlabel('$g_{11}$','Interpreter','latex','FontSize',fs)
ylabel('$g_{13}$','Interpreter','latex','FontSize',fs)
title('$d > 4$','Interpreter','latex','FontSize',fs)
ax2.FontSize = fs;

axis square


%% spontaneous network

% d < 4

d = 3;

x = -0.05:0.05:1;
y = -0.5:0.05:0.05;

[X,Y] = meshgrid(x,y);

g11dot = X + 0.5*Y./(1-X);
g13dot = 0.5*(4-d)*Y + 1.5*Y.^2./(1-X).^2;


mag = sqrt(g11dot.^2+g13dot.^2);

%% compute solutions on stable manifold

% fine tune initial values to get flow to fixed point along stable manifold

[dlsr4sol2at,dlsr4sol2ay] = ode45(@(t,y) WFfixedpoint(t,y,d),[0 15], [0.225,-0.5]);
[dlsr4sol2bt,dlsr4sol2by] = ode45(@(t,y) WFfixedpoint(t,y,d),[0 12], [0.22495,-0.5]);


theta0 = -0.81089697; % find stable manifold by rotating IC around unstable node
[dlsr4sol3t,dlsr4sol3y] = ode45(@(t,y) WFfixedpoint(t,y,d),[0 20], 0.01*[cos(theta0),sin(theta0)]);



fs = 20;
arrowSize = 15;

arrow3startidx = floor(numel(dlsr4sol3y(:,1))*0.42);

arrow6startidx = floor(numel(dlsr4sol2ay(:,1))*0.05);

arrow8startidx = floor(numel(dlsr4sol2ay(:,1))*0.23);
 
arrow10startidx = floor(numel(dlsr4sol2by(:,1))*0.7);

subplot(2,4,3)
hold on;


quiver(ax3,X,Y,g11dot./mag,g13dot./mag)

hold on;

plot(ax3,x,0*x,'LineWidth',3,'Color',[181/255 0 0])
breakidx = 26; % index at which solution switches from stable manifold to unstable


plot(ax3,dlsr4sol2ay(1:breakidx,1),dlsr4sol2ay(1:breakidx,2),'LineWidth',3,'Color',[0 0 181/255])
plot(ax3,dlsr4sol2ay(breakidx:end,1),dlsr4sol2ay(breakidx:end,2),'LineWidth',3,'Color',[181/255 0 0])

plot(ax3,dlsr4sol2by(1:breakidx,1),dlsr4sol2by(1:breakidx,2),'LineWidth',3,'Color',[0 0 181/255])
plot(ax3,dlsr4sol2by(breakidx:end,1),dlsr4sol2by(breakidx:end,2),'LineWidth',3,'Color',[181/255 0 0])

plot(ax3,dlsr4sol3y(:,1),dlsr4sol3y(:,2),'LineWidth',3,'Color',[0 0 181/255])

arrow1 = annotation('arrow','Color',[181/255 0 0],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow1.Parent = ax3; 
arrow1.Position = [0, 0, 0.5, 0]; % [x_start, y_start, delta_x, delta_y] ;

arrow3 = annotation('arrow','Color',[0 0 181/255],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow3.Parent = ax3; 
arrow3.Position = [dlsr4sol3y(arrow3startidx+1,1), dlsr4sol3y(arrow3startidx,2), dlsr4sol3y(arrow3startidx+1,1)-dlsr4sol3y(arrow3startidx,1), dlsr4sol3y(arrow3startidx+2,2)-dlsr4sol3y(arrow3startidx,2)];

arrow6 = annotation('arrow','Color',[0 0 181/255],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow6.Parent = ax3; 
arrow6.Position = [dlsr4sol2ay(arrow6startidx+1,1), dlsr4sol2ay(arrow6startidx,2), dlsr4sol2ay(arrow6startidx+1,1)-dlsr4sol2ay(arrow6startidx,1), dlsr4sol2ay(arrow6startidx+2,2)-dlsr4sol2ay(arrow6startidx,2)];

arrow8 = annotation('arrow','Color',[181/255 0 0],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow8.Parent = ax3; 
arrow8.Position = [dlsr4sol2ay(arrow8startidx,1), dlsr4sol2ay(arrow8startidx,2)-0.005, dlsr4sol2ay(arrow8startidx+1,1)-dlsr4sol2ay(arrow8startidx,1), dlsr4sol2ay(arrow8startidx+2,2)-dlsr4sol2ay(arrow8startidx,2)];

arrow10 = annotation('arrow','Color',[181/255 0 0],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow10.Parent = ax3; 
arrow10.Position = [dlsr4sol2by(arrow10startidx,1), dlsr4sol2by(arrow10startidx,2)+0.0095, dlsr4sol2by(arrow10startidx+1,1)-dlsr4sol2by(arrow10startidx,1), dlsr4sol2by(arrow10startidx+2,2)-dlsr4sol2by(arrow10startidx,2)];


plot(ax3,0,0,'o','MarkerSize',15,'MarkerEdgeColor','k','LineWidth',3)
plot(ax3,1/7,-12/49,'o','MarkerSize',15,'MarkerFaceColor','k','MarkerEdgeColor','k')


xlim([-0.05 1]);
ylim([-0.5, 0.05]);
xlabel('$g_{11}$','Interpreter','latex','FontSize',fs)
ylabel('$g_{13}$','Interpreter','latex','FontSize',fs)
title('$d < 4$','Interpreter','latex','FontSize',fs)
ax3.FontSize = fs;

axis square

%% nu exponent
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nuestO25 = load('NPRGvarphi_WF_fixedpoints_linRG_Om1n25_nu.txt');
nuestO11 = load('NPRGvarphi_WF_fixedpoints_linRG_Om1n11_nu.txt');
nuestO9 = load('NPRGvarphi_WF_fixedpoints_linRG_Om1n9_nu.txt');
nuestO7 = load('NPRGvarphi_WF_fixedpoints_linRG_Om1n7_nu.txt');
nuestO5 = load('NPRGvarphi_WF_fixedpoints_linRG_Om1n5_nu.txt');
%%
drange = 2:0.05:4;
nuestO3 = 1/2./((-50 + 25*drange - 2*drange.^2+sqrt((-10 + drange).^2.*(145 - 62*drange + 7*drange.^2)))./(6*(10 - drange)));

cmap = parula(7);

subplot(2,4,4)
hold on;
plot(ax4,drange,nuestO3,'linewidth',lw,'color',cmap(1,:))
plot(ax4,nuestO5(:,1),nuestO5(:,2),'linewidth',lw,'color',cmap(2,:))
plot(ax4,nuestO7(:,1),nuestO7(:,2),'linewidth',lw,'color',cmap(3,:))
plot(ax4,nuestO9(:,1),nuestO9(:,2),'linewidth',lw,'color',cmap(4,:))
plot(ax4,nuestO11(:,1),nuestO11(:,2),'linewidth',lw,'color',cmap(5,:))
plot(ax4,nuestO25(:,1),nuestO25(:,2),'linewidth',lw,'color',cmap(6,:))
xlim([3,4])

ax4.FontSize = fs;
xlabel('$d$','interpreter','latex','FontSize',fs)
ylabel('$\nu_\ast$','interpreter','latex','FontSize',fs)

lgd = legend('$\mathcal O(z^3)$','$\mathcal O(z^5)$','$\mathcal O(z^7)$','$\mathcal O(z^9)$','$\mathcal O(z^{11})$','$\mathcal O(z^{25})$','interpreter','latex','FontSize',0.9*fs);
legend('boxoff');
axis square

%% dimensionless nonlin plotter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% WF fixed point - spontaneous networks

z = -3:0.05:3;
lw = 3;
fs = 20;

varphistar = load('NPRGvarphi_WF_fixedpoints_criticalnonlin_Om1n11.txt')';

%%
subplot(2,4,5)
hold on;
plot(ax5,z,varphistar(1)*z+varphistar(2)*z.^3/factorial(3)...
    +varphistar(3)*z.^4/factorial(4)+varphistar(4)*z.^5/factorial(5)...
    +varphistar(5)*z.^6/factorial(6)+varphistar(6)*z.^7/factorial(7)...
    +varphistar(7)*z.^8/factorial(8)+varphistar(8)*z.^9/factorial(9)...
    +varphistar(9)*z.^10/factorial(10)+varphistar(10)*z.^11/factorial(11),'k','LineWidth',lw)
hold on;
plot(ax5,z,z*0,'k--')
axis square
xlabel('$z$','interpreter','latex')
ylabel('$\varphi_{1\ast}(z)$','interpreter','latex')
xlim([-3,3])
ylim([-3,3])
ax5.FontSize = fs;

%%

v1 = load('NPRGvarphi_WF_fixedpoints_relevantmode_Om1n11.txt')';

subplot(2,4,6)
hold on;
plot(ax6,z,v1(1)*z+v1(2)*z.^3/factorial(3)...
    +v1(3)*z.^4/factorial(4)+v1(4)*z.^5/factorial(5)...
    +v1(5)*z.^6/factorial(6)+v1(6)*z.^7/factorial(7)...
    +v1(7)*z.^8/factorial(8)+v1(8)*z.^9/factorial(9)...
    +v1(9)*z.^10/factorial(10)+v1(10)*z.^11/factorial(11),'k','LineWidth',lw)
plot(ax6,z,z*0,'k--')
axis square
xlabel('$z$','interpreter','latex')
ylabel('$v_1(z)$','interpreter','latex')
xlim([-3,3])
%ylim([-3,3])
ax6.FontSize = fs;

%%

v2 = load('NPRGvarphi_WF_fixedpoints_irrelevantmode1_Om1n11.txt')';

subplot(2,4,7)
hold on;
plot(ax7,z,v2(1)*z+v2(2)*z.^3/factorial(3)...
    +v2(3)*z.^4/factorial(4)+v2(4)*z.^5/factorial(5)...
    +v2(5)*z.^6/factorial(6)+v2(6)*z.^7/factorial(7)...
    +v2(7)*z.^8/factorial(8)+v2(8)*z.^9/factorial(9)...
    +v2(9)*z.^10/factorial(10)+v2(10)*z.^11/factorial(11),'k','LineWidth',lw)

plot(ax7,z,z*0,'k--')
axis square
xlabel('$z$','interpreter','latex')
ylabel('$v_2(z)$','interpreter','latex')
xlim([-3,3])
%ylim([-3,3])
ax7.FontSize = fs;

%%

v3 = load('NPRGvarphi_WF_fixedpoints_irrelevantmode2_Om1n11.txt')';

subplot(2,4,8)
hold on;
plot(ax8,z,v3(1)*z+v3(2)*z.^3/factorial(3)...
    +v3(3)*z.^4/factorial(4)+v3(4)*z.^5/factorial(5)...
    +v3(5)*z.^6/factorial(6)+v3(6)*z.^7/factorial(7)...
    +v3(7)*z.^8/factorial(8)+v3(8)*z.^9/factorial(9)...
    +v3(9)*z.^10/factorial(10)+v3(10)*z.^11/factorial(11),'k','LineWidth',lw)

plot(ax8,z,z*0,'k--')
axis square
xlabel('$z$','interpreter','latex')
ylabel('$v_3(z)$','interpreter','latex')
xlim([-3,3])
%ylim([-3,3])
ax8.FontSize = fs;

%%

set(isingfig,'units','normalized','position',[0 0 1.0 0.5])


%export_fig 'NPRG_isingresults.pdf' -painters -transparent
