%% NPRG Ising model results plot


%%

set(groot,'defaultAxesXTickLabelRotationMode','manual')
set(groot,'defaultAxesYTickLabelRotationMode','manual')
set(groot,'defaultAxesZTickLabelRotationMode','manual')

%%

dpfig = figure;
hold on;

%ax1 = subplot(2,4,1);
ax2 = subplot(2,4,2);
ax3 = subplot(2,4,3);
ax4 = subplot(2,4,4);
ax5 = subplot(2,4,5);
ax6 = subplot(2,4,6);
ax7 = subplot(2,4,7);
ax8 = subplot(2,4,8);

lw = 3;
fs = 20;

%% First subplot contains nothing (will put schematic there)

%% Phase planes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% absorbing state network

% d > 4

d = 5;

x = -0.5:0.05:1;
y = -1:0.05:1;

[X,Y] = meshgrid(x,y);

g11dot = X - 0.25*Y.^2./(1-X);
g12dot = -0.25*((d-4)*Y + 2*Y.^3./(1-X).^2);


mag = sqrt(g11dot.^2+g12dot.^2);

%% compute solutions on stable manifold

% fine tune initial values to get flow to fixed point along stable manifold

[dgtr4sol1t,dgtr4sol1y] = ode45(@(t,y) dpfixedpointforward(t,y,d),[0 12], [0.12208575,1.00]);
[dgtr4sol2t,dgtr4sol2y] = ode45(@(t,y) dpfixedpointforward(t,y,d),[0 12], [0.12208575,-1.00]);

%%

fs = 20;
arrowSize = 15;

arrow3startidx = floor(numel(dgtr4sol1y(:,1))/2);

subplot(2,4,2)
hold on;


quiver(ax2,X,Y,g11dot./mag,g12dot./mag)

hold on;

plot(ax2,x,0*x,'LineWidth',3,'Color',[181/255 0 0])
plot(ax2,dgtr4sol1y(:,1),dgtr4sol1y(:,2),'LineWidth',3,'Color',[0 0 181/255])
plot(ax2,dgtr4sol2y(:,1),dgtr4sol2y(:,2),'LineWidth',3,'Color',[0 0 181/255])

arrow1 = annotation('arrow','Color',[181/255 0 0],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow1.Parent = ax2; 
arrow1.Position = [0, 0, 0.2, 0]; % [x_start, y_start, delta_x, delta_y] ;

arrow2 = annotation('arrow','Color',[181/255 0 0],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow2.Parent = ax2; 
arrow2.Position = [0, 0, -0.2, 0];

arrow3 = annotation('arrow','Color',[0 0 181/255],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow3.Parent = ax2; 
arrow3.Position = [dgtr4sol1y(arrow3startidx,1), dgtr4sol1y(arrow3startidx,2), dgtr4sol1y(arrow3startidx+1,1)-dgtr4sol1y(arrow3startidx,1), dgtr4sol1y(arrow3startidx+1,2)-dgtr4sol1y(arrow3startidx,2)];

arrow4 = annotation('arrow','Color',[0 0 181/255],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow4.Parent = ax2; 
arrow4.Position = [dgtr4sol2y(arrow3startidx,1), dgtr4sol2y(arrow3startidx,2), dgtr4sol2y(arrow3startidx+1,1)-dgtr4sol2y(arrow3startidx,1), dgtr4sol2y(arrow3startidx+1,2)-dgtr4sol2y(arrow3startidx,2)];

plot(ax2,0,0,'o','MarkerSize',15,'MarkerFaceColor','k','MarkerEdgeColor','k')


xlim([-0.5 1]);
ylim([-1, 1]);
xlabel('$g_{11}$','Interpreter','latex','FontSize',fs)
ylabel('$g_{21}$','Interpreter','latex','FontSize',fs)
title('$d > 4$','Interpreter','latex','FontSize',fs)
ax2.FontSize = fs;

axis square

%% Do for d < 4:

d = 3;

x = -0.5:0.05:1;
y = -1:0.05:1;

[X,Y] = meshgrid(x,y);

g11dot = X - 0.25*Y.^2./(1-X);
g12dot = -0.25*((d-4)*Y + 2*Y.^3./(1-X).^2);


mag = sqrt(g11dot.^2+g12dot.^2);


%%


[dlsr4sol1at,dlsr4sol1ay] = ode45(@(t,y) dpfixedpointforward(t,y,d),[0 12], [0.1974,1.00]);
[dlsr4sol1bt,dlsr4sol1by] = ode45(@(t,y) dpfixedpointforward(t,y,d),[0 12], [0.1973,1.00]);


[dlsr4sol2at,dlsr4sol2ay] = ode45(@(t,y) dpfixedpointforward(t,y,d),[0 12], [0.1974,-1.00]);
[dlsr4sol2bt,dlsr4sol2by] = ode45(@(t,y) dpfixedpointforward(t,y,d),[0 12], [0.1973,-1.00]);


theta0 = 1.565801433; % find stable manifold by rotating IC around unstable node
[dlsr4sol3t,dlsr4sol3y] = ode45(@(t,y) dpfixedpointforward(t,y,d),[0 20], 0.01*[cos(theta0),sin(theta0)]);
[dlsr4sol4t,dlsr4sol4y] = ode45(@(t,y) dpfixedpointforward(t,y,d),[0 20], 0.01*[cos(theta0),-sin(theta0)]);


%%

fs = 20;
arrowSize = 15;

arrow3startidx = floor(numel(dlsr4sol3y(:,1))*0.8);
arrow4startidx = floor(numel(dlsr4sol4y(:,1))*0.8);

arrow5startidx = floor(numel(dlsr4sol1ay(:,1))*0.02);
arrow6startidx = floor(numel(dlsr4sol2ay(:,1))*0.02);

arrow7startidx = floor(numel(dlsr4sol1ay(:,1))*0.11); % use same variables as arrows 5 & 6 because they're on same curve, just further ahead
arrow8startidx = floor(numel(dlsr4sol2ay(:,1))*0.11);

arrow9startidx = floor(numel(dlsr4sol1by(:,1))*0.75); % 
arrow10startidx = floor(numel(dlsr4sol2by(:,1))*0.75);

subplot(2,4,3)
hold on;


quiver(ax3,X,Y,g11dot./mag,g12dot./mag)

hold on;

plot(ax3,x,0*x,'LineWidth',3,'Color',[181/255 0 0])
breakidx = 25; % index at which solution switches from stable manifold to unstable
plot(ax3,dlsr4sol1ay(1:breakidx,1),dlsr4sol1ay(1:breakidx,2),'LineWidth',3,'Color',[0 0 181/255])
plot(ax3,dlsr4sol1ay(breakidx:end,1),dlsr4sol1ay(breakidx:end,2),'LineWidth',3,'Color',[181/255 0 0])

plot(ax3,dlsr4sol1by(1:breakidx,1),dlsr4sol1by(1:breakidx,2),'LineWidth',3,'Color',[0 0 181/255])
plot(ax3,dlsr4sol1by(breakidx:end,1),dlsr4sol1by(breakidx:end,2),'LineWidth',3,'Color',[181/255 0 0])

plot(ax3,dlsr4sol2ay(1:breakidx,1),dlsr4sol2ay(1:breakidx,2),'LineWidth',3,'Color',[0 0 181/255])
plot(ax3,dlsr4sol2ay(breakidx:end,1),dlsr4sol2ay(breakidx:end,2),'LineWidth',3,'Color',[181/255 0 0])

plot(ax3,dlsr4sol2by(1:breakidx,1),dlsr4sol2by(1:breakidx,2),'LineWidth',3,'Color',[0 0 181/255])
plot(ax3,dlsr4sol2by(breakidx:end,1),dlsr4sol2by(breakidx:end,2),'LineWidth',3,'Color',[181/255 0 0])

plot(ax3,dlsr4sol3y(:,1),dlsr4sol3y(:,2),'LineWidth',3,'Color',[0 0 181/255])
plot(ax3,dlsr4sol4y(:,1),dlsr4sol4y(:,2),'LineWidth',3,'Color',[0 0 181/255])

arrow1 = annotation('arrow','Color',[181/255 0 0],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow1.Parent = ax3; 
arrow1.Position = [0, 0, 0.2, 0]; % [x_start, y_start, delta_x, delta_y] ;

arrow2 = annotation('arrow','Color',[181/255 0 0],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow2.Parent = ax3; 
arrow2.Position = [0, 0, -0.2, 0];

arrow3 = annotation('arrow','Color',[0 0 181/255],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow3.Parent = ax3; 
arrow3.Position = [dlsr4sol3y(arrow3startidx,1), dlsr4sol3y(arrow3startidx,2), dlsr4sol3y(arrow3startidx+1,1)-dlsr4sol3y(arrow3startidx,1), dlsr4sol3y(arrow3startidx+1,2)-dlsr4sol3y(arrow3startidx,2)];

arrow4 = annotation('arrow','Color',[0 0 181/255],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow4.Parent = ax3; 
arrow4.Position = [dlsr4sol4y(arrow4startidx,1), dlsr4sol4y(arrow4startidx,2), dlsr4sol4y(arrow4startidx+1,1)-dlsr4sol4y(arrow4startidx,1), dlsr4sol4y(arrow4startidx+1,2)-dlsr4sol4y(arrow4startidx,2)];

arrow5 = annotation('arrow','Color',[0 0 181/255],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow5.Parent = ax3; 
arrow5.Position = [dlsr4sol1ay(arrow5startidx,1), dlsr4sol1ay(arrow5startidx,2), dlsr4sol1ay(arrow5startidx+1,1)-dlsr4sol1ay(arrow5startidx,1), dlsr4sol1ay(arrow5startidx+1,2)-dlsr4sol1ay(arrow5startidx,2)];

arrow6 = annotation('arrow','Color',[0 0 181/255],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow6.Parent = ax3; 
arrow6.Position = [dlsr4sol2ay(arrow6startidx,1), dlsr4sol2ay(arrow6startidx,2), dlsr4sol2ay(arrow6startidx+1,1)-dlsr4sol2ay(arrow6startidx,1), dlsr4sol2ay(arrow6startidx+1,2)-dlsr4sol2ay(arrow6startidx,2)];

arrow7 = annotation('arrow','Color',[181/255 0 0],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow7.Parent = ax3; 
arrow7.Position = [dlsr4sol1ay(arrow7startidx,1), dlsr4sol1ay(arrow7startidx,2), dlsr4sol1ay(arrow7startidx+1,1)-dlsr4sol1ay(arrow7startidx,1), dlsr4sol1ay(arrow7startidx+1,2)-dlsr4sol1ay(arrow7startidx,2)];

arrow8 = annotation('arrow','Color',[181/255 0 0],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow8.Parent = ax3; 
arrow8.Position = [dlsr4sol2ay(arrow8startidx,1), dlsr4sol2ay(arrow8startidx,2), dlsr4sol2ay(arrow8startidx+1,1)-dlsr4sol2ay(arrow8startidx,1), dlsr4sol2ay(arrow8startidx+1,2)-dlsr4sol2ay(arrow8startidx,2)];

arrow9 = annotation('arrow','Color',[181/255 0 0],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow9.Parent = ax3; 
arrow9.Position = [dlsr4sol1by(arrow9startidx,1), dlsr4sol1by(arrow9startidx,2), dlsr4sol1by(arrow9startidx+1,1)-dlsr4sol1by(arrow9startidx,1), dlsr4sol1by(arrow9startidx+1,2)-dlsr4sol1by(arrow9startidx,2)];

arrow10 = annotation('arrow','Color',[181/255 0 0],'HeadLength',arrowSize,'HeadWidth',arrowSize);
arrow10.Parent = ax3; 
arrow10.Position = [dlsr4sol2by(arrow10startidx,1), dlsr4sol2by(arrow10startidx,2), dlsr4sol2by(arrow10startidx+1,1)-dlsr4sol2by(arrow10startidx,1), dlsr4sol2by(arrow10startidx+1,2)-dlsr4sol2by(arrow10startidx,2)];


plot(ax3,0,0,'o','MarkerSize',15,'MarkerEdgeColor','k','LineWidth',3,'MarkerFaceColor','w')
plot(ax3,1/9,4*sqrt(2)/9,'o','MarkerSize',15,'MarkerFaceColor','k','MarkerEdgeColor','k')
plot(ax3,1/9,-4*sqrt(2)/9,'o','MarkerSize',15,'MarkerFaceColor','k','MarkerEdgeColor','k')


xlim([-0.5 1]);
ylim([-1, 1]);
xlabel('$g_{11}$','Interpreter','latex','FontSize',fs)
ylabel('$g_{21}$','Interpreter','latex','FontSize',fs)
title('$d < 4$','Interpreter','latex','FontSize',fs)
ax3.FontSize = fs;

axis square

%% nu exponent
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nueps = load('NPRG_DirectedPercolation_truncation_nueps.txt');
nu3 = load('NPRG_DirectedPercolation_truncation_nuO3.txt');
nu4 = load('NPRG_DirectedPercolation_truncation_nuO4.txt');
nu5 = load('NPRG_DirectedPercolation_truncation_nuO5.txt');

%%

cmap = parula(12);

subplot(2,4,4)
plot(ax4,nueps(2:end,1),nueps(2:end,2),'k--','LineWidth',3) 
hold on; 
plot(ax4,nu3(2:end,1),nu3(2:end,2),'^','Color',cmap(3,:),'MarkerFaceColor',cmap(3,:))
plot(ax4,nu4(2:end,1),nu4(2:end,2),'o','Color',cmap(6,:),'MarkerFaceColor',cmap(6,:))
plot(ax4,nu5(2:end,1),nu5(2:end,2),'s','Color',cmap(9,:),'MarkerFaceColor',cmap(9,:))
xlabel('$d$','Interpreter','latex','FontSize',20);
ylabel('$\nu_\ast$','Interpreter','latex','FontSize',24);
lgd = legend('$\epsilon$-expansion','$\mathcal O(z^3)$','$\mathcal O(z^4)$','$\mathcal O(z^5)$','location','northeast');
lgd.Interpreter = 'latex';
lgd.FontSize = 0.8*fs;
legend('boxoff');
ax4.YAxis.FontSize = 20;
ax4.XAxis.FontSize = 20;
ylim([0.5 0.8])
axis square

%% dimensionless nonlin plotter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% DP fixed point - absorbing state networks.

z = -3:0.05:3;
lw = 3;
fs = 20;


%% Critical nonlin

wfun = load('NPRGvarphi_DP_fixedpoints_criticalpotential_d3_O5.txt');

z=0:0.05:4;


tvarphi = wfun(1,1)*(-z)+wfun(2,1)*z.^2/factorial(2)+wfun(3,1)*(-z).^3/factorial(3)...
    +wfun(4,1)*z.^4/factorial(4)+wfun(5,1)*(-z).^5/factorial(5);

subplot(2,4,5)

plot(ax5,z,wfun(1,1)*z+wfun(1,2)*z.^2/factorial(2)+wfun(1,3)*z.^3/factorial(3)...
    +wfun(1,4)*z.^4/factorial(4)+wfun(1,5)*z.^5/factorial(5),'k','LineWidth',lw)
hold on;
plot(ax5,z,-tvarphi,'r--','LineWidth',lw)
plot(ax5,z,z*0,'k--')
axis square
xlabel('$z$','interpreter','latex')
ylabel('$\varphi_{1\ast}(z)$','interpreter','latex')
xlim([0,3])
ylim([-3,1])
ax5.FontSize = fs;

%%

v1 = load('NPRGvarphi_DP_fixedpoints_relevantmode_d3_O5.txt');

tv1 = v1(1,1)*(-z)+v1(2,1)*z.^2/factorial(2)+v1(3,1)*(-z).^3/factorial(3)...
    +v1(4,1)*z.^4/factorial(4)+v1(5,1)*(-z).^5/factorial(5);

subplot(2,4,6)
plot(ax6,z,v1(1,1)*z+v1(1,2)*z.^2/factorial(2)+v1(1,3)*z.^3/factorial(3)...
    +v1(1,4)*z.^4/factorial(4)+v1(1,5)*z.^5/factorial(5),'k','LineWidth',lw)
hold on;
plot(ax6,z,-tv1,'r--','LineWidth',lw)
plot(ax6,z,z*0,'k--')
%text(1.3,0.95,'$\mu_1 = (2\nu_\ast)^{-1} = 0.85$','Interpreter','latex','FontSize',fs)
axis square
xlabel('$z$','interpreter','latex')
ylabel('$v_1(z)$','interpreter','latex')
xlim([0,3])
%ylim([-3,3])
ax6.FontSize = fs;

%%

v2 = load('NPRGvarphi_DP_fixedpoints_irrelevantmode1_d3_O5.txt');

tv2 = v2(1,1)*(-z)+v2(2,1)*z.^2/factorial(2)+v2(3,1)*(-z).^3/factorial(3)...
    +v2(4,1)*z.^4/factorial(4)+v2(5,1)*(-z).^5/factorial(5);

subplot(2,4,7)
plot(ax7,z,v2(1,1)*z+v2(1,2)*z.^2/factorial(2)+v2(1,3)*z.^3/factorial(3)...
    +v2(1,4)*z.^4/factorial(4)+v2(1,5)*z.^5/factorial(5),'k','LineWidth',lw)
hold on;
plot(ax7,z,-tv2,'r--','LineWidth',lw)
plot(ax7,z,z*0,'k--')
axis square
xlabel('$z$','interpreter','latex')
ylabel('$v_2(z)$','interpreter','latex')
xlim([0,3])
%ylim([-3,3])
ax7.FontSize = fs;

%%

v3 = load('NPRGvarphi_DP_fixedpoints_irrelevantmode2_d3_O5.txt');

tv3 = v3(1,1)*(-z)+v3(2,1)*z.^2/factorial(2)+v3(3,1)*(-z).^3/factorial(3)...
    +v3(4,1)*z.^4/factorial(4)+v3(5,1)*(-z).^5/factorial(5);

subplot(2,4,8)

plot(ax8,z,v3(1,1)*z+v3(1,2)*z.^2/factorial(2)+v3(1,3)*z.^3/factorial(3)...
    +v3(1,4)*z.^4/factorial(4)+v3(1,5)*z.^5/factorial(5),'k','LineWidth',lw)
hold on;
plot(ax8,z,-tv3,'r--','LineWidth',lw)
plot(ax8,z,z*0,'k--')
axis square
xlabel('$z$','interpreter','latex')
ylabel('$v_3(z)$','interpreter','latex')
xlim([0,3])
%ylim([-3,3])
ax8.FontSize = fs;

%%

set(dpfig,'units','normalized','position',[0 0 1.0 0.5])


%export_fig 'NPRG_dpresults.pdf' -painters -transparent
