function dydt = dpfixedpointforward(t,y,d)
  
dydt = zeros(2,1);
  
dydt(1) = y(1) - 0.25*y(2).^2./(1 - y(1));
  
dydt(2) = -0.25*((d-4)*y(2) + 2*y(2).^3./(1-y(1)).^2);

end