%% Coarse-grained network plotter -- Mar 2025

set(groot,'defaultAxesXTickLabelRotationMode','manual')
set(groot,'defaultAxesYTickLabelRotationMode','manual')
set(groot,'defaultAxesZTickLabelRotationMode','manual')

%% 3d hypertorus

% 3d nearest-neighbor lattice
J3 = load('adj_lattice_d3_L4.txt');
M = 4^3;
d = 3;
J3 = J3-eye(M);

[V3, D3] = eig(J3); %expect max-eig = 2*d*J - J_0 = 2*2*1 - 1 = 3, min-eig = -2*d*J-J0 = -5. 
D3 = diag(D3);

Lambda3Thresh = unique(round(D3,1)); %-4:2:3;

D3Thresh = zeros(M,numel(Lambda3Thresh));
J3Thresh = zeros(M,M,numel(Lambda3Thresh));

for kk=1:numel(Lambda3Thresh)

    D3Thresh(:,kk) = D3.*(D3 < Lambda3Thresh(kk));
    J3Thresh(:,:,kk) = V3*diag(D3Thresh(:,kk))*V3';

end


Jfig = figure;
hold on;

ax0 = subplot(2,6,1);
ax1 = subplot(2,6,2);
ax2 = subplot(2,6,3);
ax3 = subplot(2,6,4);
ax4 = subplot(2,6,5);
ax5 = subplot(2,6,6);

subplot(2,6,2)
imagesc(ax1,J3Thresh(:,:,2))
axis off
axis square


%caxis manual
caxis([-1 1]);
c1 = colorbar;
colorbar off;

subplot(2,6,3)
imagesc(ax2,J3Thresh(:,:,4))
axis off
axis square

%caxis manual
caxis([-1 1]);
c2 = colorbar;
colorbar off;

subplot(2,6,4)
imagesc(ax3,J3Thresh(:,:,end-1))
axis off
axis square

%caxis manual
caxis([-1 1]);
c3 = colorbar;
colorbar off;

subplot(2,6,5)
imagesc(ax4,J3Thresh(:,:,end))
axis off
axis square

%caxis manual
caxis([-1 1]);
c4 = colorbar;
colorbar off;

subplot(2,6,6)
caxis([-1 1]);
c5 = colorbar;
ax5.Visible = 'off';
ax5.FontSize = 20;
axis square

%% Plot eigenvalue density with thresholds marked

rho3lattice = load('Latticedensity_d3_J1.txt');

fs = 16;
ms = 7;

[~,lamidx1] = min(abs(rho3lattice(:,1) - Lambda3Thresh(7)));
[~,lamidx2] = min(abs(rho3lattice(:,1) - Lambda3Thresh(6)));
[~,lamidx3] = min(abs(rho3lattice(:,1) - Lambda3Thresh(4)));
[~,lamidx4] = min(abs(rho3lattice(:,1) - Lambda3Thresh(2)));

subplot(2,6,1)
hold on;
area(ax0,rho3lattice(:,1),rho3lattice(:,2),'FaceColor',[1,84/255,84/255],'LineStyle','none'); % plot mean field prediction
area(ax0,rho3lattice(1:lamidx1,1),rho3lattice(1:lamidx1,2),'FaceColor',[1,115/255,115/255],'LineStyle','none'); % plot mean field prediction
area(ax0,rho3lattice(1:lamidx2,1),rho3lattice(1:lamidx2,2),'FaceColor',[1,145/255,145/255],'LineStyle','none'); % plot mean field prediction
area(ax0,rho3lattice(1:lamidx3,1),rho3lattice(1:lamidx3,2),'FaceColor',[1,162/255,162/255],'LineStyle','none'); % plot mean field prediction
area(ax0,rho3lattice(1:lamidx4,1),rho3lattice(1:lamidx4,2),'FaceColor',[1,195/255,195/255],'LineStyle','none'); % plot mean field prediction

% add markers
plot(ax0,Lambda3Thresh(2),rho3lattice(lamidx4,2),'ko','MarkerSize',ms,'LineWidth',2)
plot(ax0,Lambda3Thresh(4),rho3lattice(lamidx3,2),'ks','MarkerSize',ms,'LineWidth',2)
plot(ax0,Lambda3Thresh(end-1),rho3lattice(lamidx2,2),'k^','MarkerSize',ms,'LineWidth',2)
plot(ax0,Lambda3Thresh(end),rho3lattice(lamidx1,2),'kp','MarkerSize',ms+5,'LineWidth',2)

axis square;
box off;
xlabel('Eigenvalue $\lambda$','Interpreter','latex','FontSize',fs);
ylim([0 0.2]);
xlim([-7.5 5.5]);
ax0.XAxis.FontSize = fs;
ax0.YAxis.FontSize = fs;


%% Random regular network -- from empty to full

rng(10)

M = 64;

numNeighbors = 3;
Jrr = full(createRandRegGraph(M,numNeighbors)); % bulk eigs are +/- 2sqrt(k-1), leading eig is k.
Jrr = Jrr - eye(M);
Jrr = Jrr - (numNeighbors-2*sqrt(numNeighbors-1))*ones(M)/M; % move outlier to max eig of bulk.
[Vrr,Drr] = eig(Jrr);
ds = 3;

Drr = diag(Drr);

LambdarrThresh = [-3.5,-3.0,0.0,1.8284]; 

DrrThresh = zeros(M,numel(LambdarrThresh));
JrrThresh = zeros(M,M,numel(LambdarrThresh));

for kk=1:numel(LambdarrThresh)

    DrrThresh(:,kk) = Drr.*(Drr < LambdarrThresh(kk));
    JrrThresh(:,:,kk) = Vrr*diag(DrrThresh(:,kk))*Vrr';
end

ax6 = subplot(2,6,7);
ax7 = subplot(2,6,8);
ax8 = subplot(2,6,9);
ax9 = subplot(2,6,10);
ax10 = subplot(2,6,11);
ax11 = subplot(2,6,12);

subplot(2,6,8)
imagesc(ax7,JrrThresh(:,:,1))
axis off
axis square

%caxis manual
caxis([-1 1]);
c1 = colorbar;
colorbar off;

subplot(2,6,9)
imagesc(ax8,JrrThresh(:,:,2))
axis off
axis square

%caxis manual
caxis([-1 1]);
c2 = colorbar;
colorbar off;

subplot(2,6,10)
imagesc(ax9,JrrThresh(:,:,3))
axis off
axis square

%caxis manual
caxis([-1 1]);
c3 = colorbar;
colorbar off;

subplot(2,6,11)
imagesc(ax10,JrrThresh(:,:,4))
axis off
axis square

%caxis manual
caxis([-1 1]);
c4 = colorbar;
colorbar off;

subplot(2,6,12)

%caxis manual
caxis([-1 1]);
c5 = colorbar;
ax11.Visible = 'off';
ax11.FontSize = 20;
axis square


%% Plot eigenvalue density with thresholds marked

y = (-4:0.01:2);

rhorr = 2*numNeighbors/pi*sqrt(max(0,4*(numNeighbors-1) - (y+1).^2))./(4*numNeighbors^2-4*(y+1).^2);

markersizeSim = 50;
markersizeLoop = 20;
linewidth = 5;
linewidthmf = 3;

[~,lamidx1] = min(abs(y - LambdarrThresh(4)));
[~,lamidx2] = min(abs(y - LambdarrThresh(3)));
[~,lamidx3] = min(abs(y - LambdarrThresh(2)));
[~,lamidx4] = min(abs(y - LambdarrThresh(1)));

subplot(2,6,7)
hold on;
area(ax6,y,rhorr,'FaceColor',[1,84/255,84/255],'LineStyle','none'); % plot mean field prediction
area(ax6,y(1:lamidx1),rhorr(1:lamidx1),'FaceColor',[1,115/255,115/255],'LineStyle','none'); % plot mean field prediction
area(ax6,y(1:lamidx2),rhorr(1:lamidx2),'FaceColor',[1,145/255,145/255],'LineStyle','none'); % plot mean field prediction
area(ax6,y(1:lamidx3),rhorr(1:lamidx3),'FaceColor',[1,162/255,162/255],'LineStyle','none'); % plot mean field prediction
area(ax6,y(1:lamidx4),rhorr(1:lamidx4),'FaceColor',[1,195/255,195/255],'LineStyle','none'); % plot mean field prediction


plot(ax6,LambdarrThresh(1),rhorr(lamidx4),'ko','MarkerSize',ms,'LineWidth',2)
plot(ax6,LambdarrThresh(2),rhorr(lamidx3),'ks','MarkerSize',ms,'LineWidth',2)
plot(ax6,LambdarrThresh(3),rhorr(lamidx2),'k^','MarkerSize',ms,'LineWidth',2)
plot(ax6,LambdarrThresh(4),rhorr(lamidx1),'kp','MarkerSize',ms+5,'LineWidth',2)

axis square;
box off;
xlabel('Eigenvalue $\lambda$','Interpreter','latex','FontSize',fs);
ylim([0 0.35]);
xlim([-4 2.0]);
ax6.XAxis.FontSize = fs;
ax6.YAxis.FontSize = fs;


%% Resize

set(Jfig,'units','normalized','position',[0 0 0.5 0.25])