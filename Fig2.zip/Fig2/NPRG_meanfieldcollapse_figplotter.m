%% Mean-field results figure

clear; 
% Evaluation of the mean-field model and scaling collapse

mffig = figure;
hold on;

ax1 = subplot(2,3,1);
ax2 = subplot(2,3,2);
ax3 = subplot(2,3,3);
ax4 = subplot(2,3,4);
ax5 = subplot(2,3,5);
ax6 = subplot(2,3,6);

lw = 3;
fs = 20;


%% Absorbing networks

N = 1;

Tmax = 1e5; % max number of timesteps

%%

dt = 0.1; % time step


% Parameters.

offset = 0.75; % background firing rate offset
Vth = log(1/offset-1);
Vs = 1.0;
phi0 = 0.5; % for sigmoid
phiprime0 = 0.25/Vs; % for sigmoid

dJ = 0.005; % increment of J0 to sweep over (as fraction of mean-field value)

Jcrit = 4*cosh(Vth/2)^2; % to account for offset
Jstart = -8*dJ;
Jend = 8*dJ;

J0vals = Jcrit*(1 + (Jstart:dJ:Jend));

icFactor = 10; 

% Starting strength of synapses (mean-field critical value)
%J0 = 1/phiprime0/(2*d-1);

Jself = 0.0; % -1 for soft refractory effect
taumem = 1.0;


VmfP = zeros(N,Tmax,numel(J0vals));

cmap = parula(19);

Jloops = numel(J0vals);

for jj = 1:Jloops

    J0 = J0vals(jj);

        % reset variables
        VP = zeros(N,Tmax);
        VP(:,1) = icFactor;


        for t=2:Tmax

            VP(:,t) = VP(:,t-1) + dt/taumem*(-VP(:,t-1)) + J0*max(0,(1./(1+exp(-(VP(:,t-1)-Vth)/Vs)))-offset)*dt/taumem;

        end

        VmfP(:,:,jj) = VP;

end

%% Plot nonlinearity

fs = 20;
lw = 3;

y = -10:0.05:10;

phimf = max(0,(1./(1+exp(-(y-Vth)/Vs)))-offset);

subplot(2,3,1)
hold on;
plot(ax1,y,phimf,'k-','LineWidth',lw)
hold on; plot(ax1,y,0*y,'k--')
    ax1.FontSize = fs;
xlabel('$\psi$','FontSize',fs,'Interpreter','latex')
ylabel('$\nu = \phi(\psi)$','FontSize',fs,'Interpreter','latex')
ylim([-0.05,0.3])
axis square

     text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'A','FontSize',32)


%% For each J0, plot psi(t) for all Eleak values


subplot(2,3,2)
    hold on;

for jj = 1:numel(J0vals) %ceil(numel(J0vals)/2)

    J0 = J0vals(jj);

        plot(ax2,(1:Tmax)*dt-dt,max(0,(1./(1+exp(-(VmfP(1,:,jj)-Vth)/Vs)))-offset),'linewidth',lw,'color',cmap(jj,:))
        plot(ax2,(1:Tmax)*dt-dt,0*(1:Tmax),'k--')

end

    ax2.FontSize = fs;
%xlim([0, 100])
%ylim([-2.5 2.5])
ax2.YScale = 'log';
ax2.XScale = 'log';
    axis square
    xlabel('$t$','interpreter','latex','fontsize',fs)
    ylabel('$\nu(t)$','interpreter','latex','fontsize',fs)
ylim([1e-4, 1e0])
xlim([1e-1, 1e4])
%export_fig 'Vdyn_critJ_spreadE_meanfield.pdf' -painters -transparent

     text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'B','FontSize',32)



%% For each J0, plot psi(t) for all Eleak values -- try scaling collapse

% alpha = 0.5;
% beta = 1.8;
% Ecest = -2.325;

dt = 0.1;

Jc = 4*cosh(Vth/2)^2;
betaexp = 1.0;
nuexp = 0.5;
zexp = 2.0;

subplot(2,3,3)
    hold on;

for jj = 1:numel(J0vals) %ceil(numel(J0vals)/2)

    J0 = J0vals(jj);

    loglog(ax3,abs(Jc-J0)^(nuexp*zexp)*((1:Tmax)*dt-dt),abs(Jc-J0)^(-betaexp)*max(0,(1./(1+exp(-(VmfP(1,:,jj)-Vth)/Vs)))-offset),'linewidth',lw,'color',cmap(jj,:))

end
        ax3.FontSize = fs;
    axis square
           xlabel('$|J_c-J|t$','Interpreter','latex','FontSize',20)
        ylabel('$\nu(t)|J_c-J|^{-1}$','Interpreter','latex','FontSize',20)
ylim([1e-4, 1e2])
xlim([1e-2, 1e3])
ax3.YScale = 'log';
ax3.XScale = 'log';

     text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'C','FontSize',32)


%% Spontaneous networks

N = 1;

Tmax = 1e3; % max number of timesteps

dt = 0.1; % time step


dJ = 0.05; % increment of J0 to sweep over (as fraction of mean-field value)

dE = 0.01; % increment of leak value to sweep over

Jcrit = 4;
Jstart = -8*dJ;
Jend = 8*dJ;

J0vals = Jcrit*(1 + (Jstart:dJ:Jend));

Ecrit = -J0vals/2;

Estart = -5*dE;
Eend = 5*dE;

Eleakdiffs = (1+ (Estart:(dE):Eend));
Eleakvals = Ecrit'*Eleakdiffs;

icFactor = 10; 

% Parameters.
Vth = 0;
Vs = 1.0;
phi0 = 0.5; % for sigmoid
phiprime0 = 0.25/Vs; % for sigmoid

% Starting strength of synapses (mean-field critical value)
%J0 = 1/phiprime0/(2*d-1);

Jself = 0.0; % -1 for soft refractory effect
offset = 0.0; % background firing rate offset
taumem = 1.0;


VmfP = zeros(N,Tmax,numel(J0vals),numel(Eleakdiffs));
VmfM = zeros(N,Tmax,numel(J0vals),numel(Eleakdiffs));


cmap = parula(13);


%%


Jloops = numel(J0vals);
Eloops = numel(Eleakdiffs);

for jj = 1:Jloops

    J0 = J0vals(jj);

    for ee=1:Eloops

        Eleak = Ecrit(jj)*(1+ Estart + dE*(ee-1)); % to avoid broadcasting issue

        % reset variables
        VP = zeros(N,Tmax);
        VP(:,1) = icFactor;

        VM = zeros(N,Tmax);
        VM(:,1) = -icFactor;


        for t=2:Tmax

            VP(:,t) = VP(:,t-1) + dt/taumem*(-VP(:,t-1) + Eleak) + J0*(1./(1+exp(-(VP(:,t-1)-Vth)/Vs)))*dt/taumem;
            VM(:,t) = VM(:,t-1) + dt/taumem*(-VM(:,t-1) + Eleak) + J0*(1./(1+exp(-(VM(:,t-1)-Vth)/Vs)))*dt/taumem;


        end

        VmfP(:,:,jj,ee) = VP;
        VmfM(:,:,jj,ee) = VM;
    end


end

%% Plot nonlinearity

y = -10:0.05:10;

phimf = 1./(1+exp(-y));

subplot(2,3,4)
hold on;
plot(ax4,y,phimf,'k-','LineWidth',lw)
hold on; plot(ax4,y,0*y,'k--')
    ax4.FontSize = fs;
xlabel('$\psi$','FontSize',fs,'Interpreter','latex')
ylabel('$\nu = \phi(\psi)$','FontSize',fs,'Interpreter','latex')
ylim([-0.1,1.1])
axis square

     text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'D','FontSize',32)


%% For each J0, plot psi(t) for all Eleak values


jj = 9; %1:numel(J0vals) %ceil(numel(J0vals)/2)

    J0 = J0vals(jj);

subplot(2,3,5)
    hold on;

    for ee=1:numel(Eleakdiffs)


        plot(ax5,(1:Tmax)*dt-dt,1./(1+exp(-VmfP(1,:,jj,ee))),'linewidth',lw,'color',cmap(ee,:))
        plot(ax5,(1:Tmax)*dt-dt,1./(1+exp(-VmfM(1,:,jj,ee))),'linewidth',lw,'color',cmap(ee,:))
        plot(ax5,(1:Tmax)*dt-dt,0*(1:Tmax)+0.5,'k--')

    end


    ax5.FontSize = fs;
xlim([0, 100])
ylim([0 1.2])
    axis square
    xlabel('$t$','interpreter','latex','fontsize',fs)
    ylabel('$\nu_\pm(t)$','interpreter','latex','fontsize',fs)


     text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'E','FontSize',32)


%% Scaling collapse

dt = 0.1;


alpha = 0.5; 
thetac = 0.0;

jj = 9;

    J0 = J0vals(jj);

subplot(2,3,6)
    hold on;

    for ee=1:numel(Eleakdiffs)


        Eleak = Eleakvals(jj,ee);


        plot(ax6,(Eleak-Ecrit(jj))*((1:Tmax)*dt-dt).^(1+alpha),(1./(1+exp(-VmfP(1,:,jj,ee)))- 1./(1+exp(-VmfM(1,:,jj,ee)))).*((1:Tmax)*dt-dt).^alpha,'linewidth',lw,'color',cmap(ee,:))

    end

        ax6.FontSize = fs;
    axis square
           xlabel('$(\mathcal E - \mathcal E_c(J_c))t^{3/2}$','Interpreter','latex','FontSize',20)
        ylabel('$(\nu_+(t) - \nu_-(t))t^{1/2}$','Interpreter','latex','FontSize',20)

xlim([-40 40])

     text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'F','FontSize',32)


