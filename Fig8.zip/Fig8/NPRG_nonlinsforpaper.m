% Plot NPRG predictions vs simulations

close all;

% plot params
lw = 3;

%mean-field nonlinearity
x = -10:0.1:10;
phi = 1./(1+exp(-x));

cmap = parula(8);

%% 3d Lattice


% Absorbing networks
Ntrials = 100;
Tmax = 1000;
N = 14^3;
d = 3;

J0 = 0.4125; 
nprgrateabsorbingd3J0p4125 = load('NPRGPhi_lattice_d3_absorbingsigmoid_J0p4125_O4.txt');
fname =  ['Lattice_absorbing_nonlinsweep_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simabsorbingd3J0p4125= load(fname);

J0 = 0.825; 
nprgrateabsorbingd3J0p825 = load('NPRGPhi_lattice_d3_absorbingsigmoid_J0p825_O4.txt');
fname =  ['Lattice_absorbing_nonlinsweep_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simabsorbingd3J0p825= load(fname);

J0 = 1.65; 
nprgrateabsorbingd3J1p65 = load('NPRGPhi_lattice_d3_absorbingsigmoid_J1p65_O4.txt');
fname =  ['Lattice_absorbing_nonlinsweep_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(10*Tmax) '_J'  num2str(J0)   '.txt'];
simabsorbingd3J1p65= load(fname);

% Spontaneous networks
nprgrated3J0p5825 = load('NPRGPhi_lattice_d3_sigmoid_J0p5825_O4.txt');
simd3J0p5825= load('Lattice_nonlinsweep_d3_Ntrials100_N3375_Tmax1000_J0.5825_Eleak-1.3313.txt');

nprgrated3J1p165 = load('NPRGPhi_lattice_d3_sigmoid_J1p165_O4.txt');
simd3J1p165= load('Lattice_nonlinsweep_d3_Ntrials100_N3375_Tmax1000_J1.165_Eleak-2.7875.txt');

nprgrated3J2p33 = load('NPRGPhi_lattice_d3_sigmoid_J2p33_O4.txt');
simd3J2p33= load('Lattice_nonlinsweep_d3_Ntrials100_N3375_Tmax1000_J2.33_Eleak-5.7.txt');




%% k = 3 random regular graph

numNeighbors = 3;
Ntrials = 100;
Tmax = 1000;
N = 2^11;

% absorbing

J0 = 1.085; 
nprgrateabsorbingRRdeg3J1p085 = load('NPRGPhi_randreg_deg3_absorbingsigmoid_J1p085_O4.txt');
fname =  ['RandomRegularGraph_absorbing_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simabsorbingRRdeg3J1p085= load(fname);

J0 = 2.17; 
nprgrateabsorbingRRdeg3J2p17 = load('NPRGPhi_randreg_deg3_absorbingsigmoid_J2p17_O4.txt');
fname =  ['RandomRegularGraph_absorbing_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simabsorbingRRdeg3J2p17= load(fname);

J0 = 4.34; 
nprgrateabsorbingRRdeg3J4p34 = load('NPRGPhi_randreg_deg3_absorbingsigmoid_J4p34_O4.txt');
fname =  ['RandomRegularGraph_absorbing_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simabsorbingRRdeg3J4p34= load(fname);

% spont
J0 = 1.875; 
nprgratespontRRdeg3J1p875 = load('NPRGPhi_randreg_deg3_spontsigmoid_J1p875_O4.txt');
fname =  ['RandomRegularGraph_spontaneous_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simspontRRdeg3J1p875= load(fname);

J0 = 3.75; 
nprgratespontRRdeg3J3p75 = load('NPRGPhi_randreg_deg3_spontsigmoid_J3p75_O4.txt');
fname =  ['RandomRegularGraph_spontaneous_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simspontRRdeg3J3p75= load(fname);

J0 = 7.5; 
nprgratespontRRdeg3J7p5 = load('NPRGPhi_randreg_deg3_spontsigmoid_J7p5_O4.txt');
fname =  ['RandomRegularGraph_spontaneous_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simspontRRdeg3J7p5 = load(fname);


%% k = 3 random regular graph with global inhib

numNeighbors = 3;
Ntrials = 100;
Tmax = 1000;
N = 2^11;

% absorbing

J0 = 1.16; 
nprgrateabsorbingRRdeg3J1p16 = load('NPRGPhi_randreg_deg3_absorbingsigmoid_J1p16_O4.txt');
fname =  ['RandomRegularGraphwithInhib_absorbing_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simabsorbingRRdeg3J1p16= load(fname);

J0 = 2.32; 
nprgrateabsorbingRRdeg3J2p32 = load('NPRGPhi_randreg_deg3_absorbingsigmoid_J2p32_O4.txt');
fname =  ['RandomRegularGraphwithInhib_absorbing_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simabsorbingRRdeg3J2p32= load(fname);

J0 = 4.64; 
nprgrateabsorbingRRdeg3J4p64 = load('NPRGPhi_randreg_deg3_absorbingsigmoid_J4p64_O4.txt');
fname =  ['RandomRegularGraphwithInhib_absorbing_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simabsorbingRRdeg3J4p64= load(fname);


% spont

J0 = 3.0; 
nprgratespontRRdeg3J3p0 = load('NPRGPhi_randreg_deg3_spontsigmoid_J3p0_O4.txt');
fname =  ['RandomRegularGraphwithInhib_spontaneous_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simspontRRdeg3J3p0= load(fname);

J0 = 6.0; 
nprgratespontRRdeg3J6p0 = load('NPRGPhi_randreg_deg3_spontsigmoid_J6p0_O4.txt');
fname =  ['RandomRegularGraphwithInhib_spontaneous_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
simspontRRdeg3J6p0= load(fname);

J0 = 12.0; 
nprgratespontRRdeg3J12p0 = load('NPRGPhi_randreg_deg3_spontsigmoid_J12p0_O4.txt');
fname =  ['RandomRegularGraphwithInhib_spontaneous_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(5*Tmax) '_J'  num2str(J0)   '.txt'];
simspontRRdeg3J12p0= load(fname);

%% 3d lattice - abs


figure;
ax1 = axes;

plot(ax1,simabsorbingd3J0p4125(2:end,1),simabsorbingd3J0p4125(2:end,2),'LineWidth',3*lw,'Color',cmap(2,:))
hold on;
plot(ax1,simabsorbingd3J0p825(2:end,1),simabsorbingd3J0p825(2:end,2),'LineWidth',3*lw,'Color',cmap(4,:))
plot(ax1,simabsorbingd3J1p65(2:end,1),simabsorbingd3J1p65(2:end,2),'LineWidth',3*lw,'Color',cmap(6,:))
plot(ax1,nprgrateabsorbingd3J0p4125(:,1),nprgrateabsorbingd3J0p4125(:,2),'-.','LineWidth',lw,'Color',[0.6350 0.0780 0.1840])
plot(ax1,x,phi-0.5,'k--','LineWidth',lw)
plot(ax1,nprgrateabsorbingd3J0p825(:,1),nprgrateabsorbingd3J0p825(:,2),'-.','LineWidth',lw,'Color',0.9*[0.6350 0.0780 0.1840])
plot(ax1,nprgrateabsorbingd3J1p65(:,1),nprgrateabsorbingd3J1p65(:,2),'-.','LineWidth',lw,'Color',0.8*[0.6350 0.0780 0.1840])
xlim([0,10])
ylim([0,0.6])
xlabel('$\psi$','interpreter','latex')
ylabel('$\nu = \Phi(\psi)$','interpreter','latex')
text(0.5,0.55,'A','FontSize',32)
set(gca,'FontSize',20)
axis square
lgd = legend('Sim. $J=J_c/2$','Sim. $J=J_c$','Sim. $J=2J_c$','RG','mean-field','location','southeast','FontSize',20);
lgd.Interpreter = 'latex';
legend('boxoff')

figure;
ax2 = axes;

plot(ax2,simd3J0p5825(1:end-1,1),simd3J0p5825(1:end-1,2),'LineWidth',3*lw,'Color',cmap(2,:))
hold on;
plot(ax2,simd3J1p165(1:end-1,1),simd3J1p165(1:end-1,2),'LineWidth',3*lw,'Color',cmap(4,:))
plot(ax2,simd3J2p33(1:end-1,1),simd3J2p33(1:end-1,2),'LineWidth',3*lw,'Color',cmap(6,:))
plot(ax2,nprgrated3J0p5825(:,1),nprgrated3J0p5825(:,2),'-.','LineWidth',lw,'Color',[0.6350 0.0780 0.1840])
plot(ax2,x,phi,'k--','LineWidth',lw)
plot(ax2,nprgrated3J1p165(:,1),nprgrated3J1p165(:,2),'-.','LineWidth',lw,'Color',0.9*[0.6350 0.0780 0.1840])
plot(ax2,nprgrated3J2p33(:,1),nprgrated3J2p33(:,2),'-.','LineWidth',lw,'Color',0.8*[0.6350 0.0780 0.1840])
xlabel('$\psi$','interpreter','latex')
ylabel('$\nu = \Phi(\psi)$','interpreter','latex')
ylim([0,1.2])
text(-9.0,1.1,'B','FontSize',32)
set(gca,'FontSize',20)
axis square

%% rand reg deg 3 - abs


figure;
ax3 = axes;

plot(ax3,simabsorbingRRdeg3J1p085(2:end,1),simabsorbingRRdeg3J1p085(2:end,2),'LineWidth',3*lw,'Color',cmap(2,:))
hold on;
plot(ax3,simabsorbingRRdeg3J2p17(2:end,1),simabsorbingRRdeg3J2p17(2:end,2),'LineWidth',3*lw,'Color',cmap(4,:))
plot(ax3,simabsorbingRRdeg3J4p34(2:end,1),simabsorbingRRdeg3J4p34(2:end,2),'LineWidth',3*lw,'Color',cmap(6,:))
plot(ax3,nprgrateabsorbingRRdeg3J1p085(:,1),nprgrateabsorbingRRdeg3J1p085(:,2),'-.','LineWidth',lw,'Color',[0.6350 0.0780 0.1840])
plot(ax3,x,phi-0.5,'k--','LineWidth',lw)
plot(ax3,nprgrateabsorbingRRdeg3J2p17(:,1),nprgrateabsorbingRRdeg3J2p17(:,2),'-.','LineWidth',lw,'Color',0.9*[0.6350 0.0780 0.1840])
plot(ax3,nprgrateabsorbingRRdeg3J4p34(:,1),nprgrateabsorbingRRdeg3J4p34(:,2),'-.','LineWidth',lw,'Color',0.8*[0.6350 0.0780 0.1840])
xlim([0,10])
ylim([0,0.6])
text(0.5,0.55,'C','FontSize',32)
set(gca,'FontSize',20)
axis square

%% deg 3 random regular graph

lw = 3;
fs = 20;

figure;
ax4 = axes;

plot(ax4,simspontRRdeg3J1p875(1:end-1,1),simspontRRdeg3J1p875(1:end-1,2),'LineWidth',3*lw,'Color',cmap(2,:))
hold on;
plot(ax4,simspontRRdeg3J3p75(1:end-1,1),simspontRRdeg3J3p75(1:end-1,2),'LineWidth',3*lw,'Color',cmap(4,:))
plot(ax4,simspontRRdeg3J7p5(1:end-1,1),simspontRRdeg3J7p5(1:end-1,2),'LineWidth',3*lw,'Color',cmap(6,:))
plot(ax4,nprgratespontRRdeg3J1p875(:,1),nprgratespontRRdeg3J1p875(:,2),'-.','LineWidth',lw,'Color',[0.6350 0.0780 0.1840])
plot(ax4,x,phi,'k--','LineWidth',lw)
plot(ax4,nprgratespontRRdeg3J3p75(:,1),nprgratespontRRdeg3J3p75(:,2),'-.','LineWidth',lw,'Color',0.9*[0.6350 0.0780 0.1840])
plot(ax4,nprgratespontRRdeg3J7p5(:,1),nprgratespontRRdeg3J7p5(:,2),'-.','LineWidth',lw,'Color',0.8*[0.6350 0.0780 0.1840])
xlim([-10,10])
ylim([0,1.2])
text(-9.0,1.1,'D','FontSize',32)
set(gca,'FontSize',20)
axis square

%% rand reg with inhib deg 3 - abs


figure;
ax5 = axes;

plot(ax5,simabsorbingRRdeg3J1p16(2:end,1),simabsorbingRRdeg3J1p16(2:end,2),'LineWidth',3*lw,'Color',cmap(2,:))
hold on;
plot(ax5,simabsorbingRRdeg3J2p32(2:end,1),simabsorbingRRdeg3J2p32(2:end,2),'LineWidth',3*lw,'Color',cmap(4,:))
plot(ax5,simabsorbingRRdeg3J4p64(2:end,1),simabsorbingRRdeg3J4p64(2:end,2),'LineWidth',3*lw,'Color',cmap(6,:))
plot(ax5,nprgrateabsorbingRRdeg3J1p16(:,1),nprgrateabsorbingRRdeg3J1p16(:,2),'-.','LineWidth',lw,'Color',[0.6350 0.0780 0.1840])
plot(ax5,x,phi-0.5,'k--','LineWidth',lw)
plot(ax5,nprgrateabsorbingRRdeg3J2p32(:,1),nprgrateabsorbingRRdeg3J2p32(:,2),'-.','LineWidth',lw,'Color',0.9*[0.6350 0.0780 0.1840])
plot(ax5,nprgrateabsorbingRRdeg3J4p64(:,1),nprgrateabsorbingRRdeg3J4p64(:,2),'-.','LineWidth',lw,'Color',0.8*[0.6350 0.0780 0.1840])
xlim([0,10])
ylim([0,0.6])
text(0.5,0.55,'E','FontSize',32)
set(gca,'FontSize',20)
axis square
lgd5 = legend('Sim. $J=J_c/2$','Sim. $J=J_c$','Sim. $J=2J_c$','RG','mean-field','location','southeast','FontSize',12);
lgd5.Interpreter = 'latex';
legend('boxoff')

%% rand reg with inhib deg 3 - spont


figure;
ax6 = axes;

plot(ax6,simspontRRdeg3J3p0(1:end-1,1),simspontRRdeg3J3p0(1:end-1,2),'LineWidth',3*lw,'Color',cmap(2,:))
hold on;
plot(ax6,simspontRRdeg3J6p0(1:end-1,1),simspontRRdeg3J6p0(1:end-1,2),'LineWidth',3*lw,'Color',cmap(4,:))
plot(ax6,simspontRRdeg3J12p0(2:end,1),simspontRRdeg3J12p0(2:end,2),'LineWidth',3*lw,'Color',cmap(6,:))
plot(ax6,nprgratespontRRdeg3J3p0(:,1),nprgratespontRRdeg3J3p0(:,2),'-.','LineWidth',lw,'Color',[0.6350 0.0780 0.1840])
plot(ax6,x,phi,'k--','LineWidth',lw)
plot(ax6,nprgratespontRRdeg3J6p0(:,1),nprgratespontRRdeg3J6p0(:,2),'-.','LineWidth',lw,'Color',0.9*[0.6350 0.0780 0.1840])
plot(ax6,nprgratespontRRdeg3J12p0(:,1),nprgratespontRRdeg3J12p0(:,2),'-.','LineWidth',lw,'Color',0.8*[0.6350 0.0780 0.1840])
xlim([-10 10])
ylim([0,1.2])
text(-9.0,1.1,'F','FontSize',32)
set(gca,'FontSize',20)
axis square

%% All in one subfigure


fig1to6 = figure;
axs1 = subplot(2,3,1,'parent',fig1to6);
axs2 = subplot(2,3,4,'parent',fig1to6);
axs3 = subplot(2,3,2,'parent',fig1to6);
axs4 = subplot(2,3,5,'parent',fig1to6);
axs5 = subplot(2,3,3,'parent',fig1to6);
axs6 = subplot(2,3,6,'parent',fig1to6);

axcp1 = copyobj(ax1, fig1to6);
set(axcp1,'Position',get(axs1,'position'));
delete(axs1);

axcp2 = copyobj(ax2, fig1to6);
set(axcp2,'Position',get(axs2,'position'));
delete(axs2);

axcp3 = copyobj(ax3, fig1to6);
set(axcp3,'Position',get(axs3,'position'));
delete(axs3);

axcp4 = copyobj(ax4, fig1to6);
set(axcp4,'Position',get(axs4,'position'));
delete(axs4);

axcp5 = copyobj([ax5,lgd5], fig1to6);
set(axcp5,'Position',get(axs5,'position'));
lgdtmp = findobj(gcf, 'Type', 'Legend');
lgdtmp.Location = 'southeast';
delete(axs5);

axcp6 = copyobj(ax6, fig1to6);
set(axcp6,'Position',get(axs6,'position'));
delete(axs6);

set(fig1to6,'units','normalized','position',[0 0 0.5 0.5])