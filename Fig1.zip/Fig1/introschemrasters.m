%% Spike rasters for intro schematic

NE = 2^11;
NI = 2^9;
numNeighbors = 3;
Ntrials = 1;
icFactor = 10;
dt = 0.01;

fs = 20;
lw = 3;

figure;
ax1 = subplot(2,4,1);
ax2 = subplot(2,4,2);
ax3 = subplot(2,4,3);
ax4 = subplot(2,4,4);
ax5 = subplot(2,4,5);
ax6 = subplot(2,4,6);
ax7 = subplot(2,4,7);
ax8 = subplot(2,4,8);

%% Phase diagrams

% absorbing
subplot(2,4,1)
hold on;

plot(ax1,2.32:0.01:5,zeros(size(2.32:0.01:5)),'k-','linewidth',lw)
plot(ax1,0:0.01:5,zeros(size(0:0.01:5)),'k--','linewidth',1)
plot(ax1,2.32,0,'p','MarkerSize',20,'MarkerFaceColor',[181/255 0 0])
plot(ax1,2.32/2,0,'o','MarkerSize',10,'MarkerFaceColor',[181/255 0 0])
plot(ax1,2.32*2,0,'s','MarkerSize',10,'MarkerFaceColor',[181/255 0 0])
xlabel('Synaptic strength $J$','interpreter','latex','Fontsize',fs)
ylabel('Equilibrium potential $\mathcal E$','interpreter','latex','Fontsize',fs)
xlim([0,5])
ylim([-1 1])
ax1.FontSize = fs;

    text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'A','FontSize',32)

    text('Units', 'Normalized', 'Position', [0.05, 0.45], 'string', 'quiescent','interpreter','latex','FontSize',fs)
    text('Units', 'Normalized', 'Position', [0.75, 0.55], 'string', 'active','interpreter','latex','FontSize',fs)

axis square

% spontaneous
subplot(2,4,5)
hold on;

plot(ax5,6.0:0.1:15,(-4.725-(-5.625+4.725)/(7.5-6.0)*6+(-5.625+4.725)/(7.5-6.0)*(6.0:0.1:15)*1.1),'k-','linewidth',lw)
plot(ax5,0:0.1:15,(-4.725-(-5.625+4.725)/(7.5-6.0)*6+(-5.625+4.725)/(7.5-6.0)*(0.0:0.1:15)*1.1),'k--','linewidth',1)
plot(ax5,6.0,(-4.725-(-5.625+4.725)/(7.5-6.0)*6+(-5.625+4.725)/(7.5-6.0)*6*1.1),'p','MarkerSize',20,'MarkerFaceColor',[181/255 0 0])
plot(ax5,3.0,(-4.725-(-5.625+4.725)/(7.5-6.0)*6+(-5.625+4.725)/(7.5-6.0)*3*1.1),'o','MarkerSize',10,'MarkerFaceColor',[181/255 0 0])
plot(ax5,12,(-4.725-(-5.625+4.725)/(7.5-6.0)*6+(-5.625+4.725)/(7.5-6.0)*12*1.1),'s','MarkerSize',10,'MarkerFaceColor',[181/255 0 0])
xlabel('Synaptic strength $J$','interpreter','latex','Fontsize',fs)
ylabel('Equilibrium potential $\mathcal E$','interpreter','latex','Fontsize',fs)
% xlim([0,5])
% ylim([-1 1])
ax5.FontSize = fs;

    text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'E','FontSize',32)

t1 =    text('Units', 'Normalized', 'Position', [0.05, 0.75], 'string', 'asynchronous','interpreter','latex','FontSize',fs);
t1.Rotation = atan((-5.625+4.725)/(7.5-6.0)*1.1)*215/pi;

t2 =    text('Units', 'Normalized', 'Position', [0.55, 0.6], 'string', 'high/low firing','interpreter','latex','FontSize',fs);
t2.Rotation = atan((-5.625+4.725)/(7.5-6.0)*1.1)*215/pi;

axis square

%% absorbing


Tmax = 5000;

J0 = 2.32/2;
fname =  ['RandomRegularGraphEIExplicit_absorbing_forintroschematic_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_.txt'];
rasterabsJ1p16 = load(fname);
rasterabsJ1p16(rasterabsJ1p16 == 0) = NaN;

J0 = 2.32;
fname =  ['RandomRegularGraphEIExplicit_absorbing_forintroschematic_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_.txt'];
rasterabsJ2p32 = load(fname);
rasterabsJ2p32(rasterabsJ2p32 == 0) = NaN;

J0 = 2*2.32;
fname =  ['RandomRegularGraphEIExplicit_absorbing_forintroschematic_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_.txt'];
rasterabsJ4p64 = load(fname);
rasterabsJ4p64(rasterabsJ4p64 == 0) = NaN;


%% spontaneous


Tmax = 2e4;

% J = Jc/2, E = 1.1*Ecest
J0 = 3.0;
Eleak = 1.1*(-4.725-(-5.625+4.725)/(7.5-6.0)*6+(-5.625+4.725)/(7.5-6.0)*J0);
fname =  ['RandomRegularGraphEIExplicit_spontaneous_forintroschematic_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
rasterspontJ3p0 = load(fname);
rasterspontJ3p0(rasterspontJ3p0 == 0) = NaN;

% J = Jc, E = 1.1*Ecest
J0 = 6.0;
Eleak = 1.1*(-4.725-(-5.625+4.725)/(7.5-6.0)*6+(-5.625+4.725)/(7.5-6.0)*J0);
fname =  ['RandomRegularGraphEIExplicit_spontaneous_forintroschematic_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
rasterspontJ6p0 = load(fname);
rasterspontJ6p0(rasterspontJ6p0 == 0) = NaN;

% J = 2*Jc, E = 1.1*Ecest
J0 = 12.0;
Eleak = 1.1*(-4.725-(-5.625+4.725)/(7.5-6.0)*6+(-5.625+4.725)/(7.5-6.0)*J0);
fname =  ['RandomRegularGraphEIExplicit_spontaneous_forintroschematic_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
rasterspontJ12p0 = load(fname);
rasterspontJ12p0(rasterspontJ12p0 == 0) = NaN;

%% Absorbing state rasters

Tmax = 5000;

%subcrit
subplot(2,4,2)
hold on;

for ii=1:NE
scatter(ax2,(1:Tmax)*dt,ii*(rasterabsJ1p16(ii,:) > 0),10,[1,0,0],'filled')
end
for ii=(1+NE):(NE+NI)
scatter(ax2,(1:Tmax)*dt,ii*(rasterabsJ1p16(ii,:) > 0),10,[0,0,1],'filled')
end
xlim([0,50])
ylim([1,NE+NI])
xlabel('time (units of $\tau$)','Interpreter','latex','FontSize',fs)
ylabel('Neuron number','Interpreter','latex','FontSize',fs)
ax2.FontSize = fs;
axis square

%    text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'B','FontSize',32)


% crit
subplot(2,4,3)
hold on;

for ii=1:NE
scatter(ax3,(1:Tmax)*dt,ii*(rasterabsJ2p32(ii,:) > 0),10,[1,0,0],'filled')
end
for ii=(1+NE):(NE+NI)
scatter(ax3,(1:Tmax)*dt,ii*(rasterabsJ2p32(ii,:) > 0),10,[0,0,1],'filled')
end
xlim([0,50])
ylim([1,NE+NI])
xlabel('time (units of $\tau$)','Interpreter','latex','FontSize',fs)
ylabel('Neuron number','Interpreter','latex','FontSize',fs)
ax3.FontSize = fs;
axis square

%    text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'C','FontSize',32)


% supercrit
subplot(2,4,4)
hold on;

for ii=1:NE
scatter(ax4,(1:Tmax)*dt,ii*(rasterabsJ4p64(ii,:) > 0),10,[1,0,0],'filled')
end
for ii=(1+NE):(NE+NI)
scatter(ax4,(1:Tmax)*dt,ii*(rasterabsJ4p64(ii,:) > 0),10,[0,0,1],'filled')
end
xlim([0,50])
ylim([1,NE+NI])
xlabel('time (units of $\tau$)','Interpreter','latex','FontSize',fs)
ylabel('Neuron number','Interpreter','latex','FontSize',fs)
ax4.FontSize = fs;
axis square

 %   text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'D','FontSize',32)


%% Spontaneous rasters

Tmax = 2e4;

%subcrit
subplot(2,4,6)
hold on;

for ii=1:NE
scatter(ax6,(1:Tmax)*dt,ii*(rasterspontJ3p0(ii,:) > 0),10,[1,0,0],'filled')
end
for ii=(1+NE):(NE+NI)
scatter(ax6,(1:Tmax)*dt,ii*(rasterspontJ3p0(ii,:) > 0),10,[0,0,1],'filled')
end
xlim([0,200])
ylim([1,NE+NI])
xlabel('time (units of $\tau$)','Interpreter','latex','FontSize',fs)
ylabel('Neuron number','Interpreter','latex','FontSize',fs)
ax6.FontSize = fs;
axis square

%    text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'F','FontSize',32)


% crit
subplot(2,4,7)
hold on;

for ii=1:NE
scatter(ax7,(1:Tmax)*dt,ii*(rasterspontJ6p0(ii,:) > 0),10,[1,0,0],'filled')
end
for ii=(1+NE):(NE+NI)
scatter(ax7,(1:Tmax)*dt,ii*(rasterspontJ6p0(ii,:) > 0),10,[0,0,1],'filled')
end
xlim([0,200])
ylim([1,NE+NI])
xlabel('time (units of $\tau$)','Interpreter','latex','FontSize',fs)
ylabel('Neuron number','Interpreter','latex','FontSize',fs)
ax7.FontSize = fs;
axis square

%    text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'G','FontSize',32)


% supercrit
subplot(2,4,8)
hold on;

for ii=1:NE
scatter(ax8,(1:Tmax)*dt,ii*(rasterspontJ12p0(ii,:) > 0),10,[1,0,0],'filled')
end
for ii=(1+NE):(NE+NI)
scatter(ax8,(1:Tmax)*dt,ii*(rasterspontJ12p0(ii,:) > 0),10,[0,0,1],'filled')
end
xlim([0,200])
ylim([1,NE+NI])
xlabel('time (units of $\tau$)','Interpreter','latex','FontSize',fs)
ylabel('Neuron number','Interpreter','latex','FontSize',fs)
ax8.FontSize = fs;
axis square

 %   text('Units', 'Normalized', 'Position', [0.05, 0.925], 'string', 'H','FontSize',32)
