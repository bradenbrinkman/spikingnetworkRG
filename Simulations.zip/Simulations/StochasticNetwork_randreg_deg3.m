
% Simulation of the stochastic spiking model to test critical point
% hypothesis

% simulates both V(:,1) = icFactor and -icFactor in same loop.

tic

rng(1) % set rng seed

N = 2048;
numNeighbors = 3;
J = full(createRandRegGraph(N,numNeighbors)); % bulk eigs are +/- 2sqrt(k-1), leading eig is k.
J = J - eye(N);
[Vj,Dj] = eig(J);
ds = 3;


Tmax = 1e3; % max number of timesteps
Ntrials = 10;

%%

rng(2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% For big sweep to estimate Ec(J)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Jcrit = 3.5; % central value of J to sweep around

dJ = 0.25;  % increment

Jstart = -6*dJ; 
Jend = 6*dJ;

J0vals = Jcrit + (Jstart:dJ:Jend); % note: different from the lattices!

dE = 0.05; % increment of leak value to sweep over

Estart = -9*dE;
Eend = 9*dE;

Ecrit  = -3.5*ones(size(J0vals));

% took about 3 hours to run
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Eleakdiffs = (1+ (Estart:(dE):Eend));

Eleakvals = Ecrit'*Eleakdiffs;

icFactor = 10; 

dt = 0.1; % time step

% Parameters.
Vth = 0;
Vs = 1.0;
phi0 = 0.5; % for sigmoid
phiprime0 = 0.25/Vs; % for sigmoid

% Starting strength of synapses (mean-field critical value)
%J0 = 1/phiprime0/(2*d-1);

Jself = 0.0; % -1 for soft refractory effect
offset = 0.0; % background firing rate offset
taumem = 1.0;



%%

Jloops = numel(J0vals);
Eloops = numel(Eleakdiffs);

parfor jj = 1:Jloops

    J0 = J0vals(jj);

    for ee=1:Eloops


        Eleak = Ecrit(jj)*(1+ Estart + dE*(ee-1)); % to avoid broadcasting issue

        % reset average variables

        VavgP = zeros(N,Tmax);
        VavgM = zeros(N,Tmax);

        V2avgP = zeros(N,Tmax);
        V2avgM = zeros(N,Tmax);

        dNavgP = zeros(N,Tmax);
        dNavgM = zeros(N,Tmax);

        dN2avgP= zeros(N,Tmax);
        dN2avgM= zeros(N,Tmax);


        for h=1:Ntrials

            % set stochastic vars
            VP = zeros(N,Tmax);
            VP(:,1) = icFactor;

            VM = zeros(N,Tmax);
            VM(:,1) = -icFactor;

            dNP = zeros(N,Tmax);
            dNM = zeros(N,Tmax);

            % change seed to change spiking activity
            rng(ceil(Eloops)*(1+h))

            for t=2:Tmax

                dNP(:,t) = poissrnd(dt*(offset+1./(1+exp(-(VP(:,t-1)-Vth)/Vs)))); % sigmoid with offset
                dNM(:,t) = poissrnd(dt*(offset+1./(1+exp(-(VM(:,t-1)-Vth)/Vs)))); % sigmoid with offset


                VP(:,t) = VP(:,t-1) + dt/taumem*(-VP(:,t-1) + Eleak) + (J0*J+Jself*eye(N))*dNP(:,t)/taumem;
                VM(:,t) = VM(:,t-1) + dt/taumem*(-VM(:,t-1) + Eleak) + (J0*J+Jself*eye(N))*dNM(:,t)/taumem;


            end

            VavgP = VavgP + VP;

            V2avgP = V2avgP + VP.^2;

            dNavgP = dNavgP + dNP;

            dN2avgP = dN2avgP + dNP.^2;


            VavgM = VavgM + VM;

            V2avgM = V2avgM + VM.^2;

            dNavgM = dNavgM + dNM;

            dN2avgM = dN2avgM + dNM.^2;



        end

        % update trial averages
        VavgP = VavgP/Ntrials;

        dNavgP = dNavgP/Ntrials;

        V2avgP = V2avgP/Ntrials - VavgP.^2;

        dN2avgP = dN2avgP/Ntrials - dNavgP.^2;


        VavgM = VavgM/Ntrials;

        dNavgM = dNavgM/Ntrials;

        V2avgM = V2avgM/Ntrials - VavgM.^2;

        dN2avgM = dN2avgM/Ntrials - dNavgM.^2;


        % calculate population averages and print:
        VavgpopP = mean(VavgP,1);
        VavgpopstdP = std(VavgP,1);

        V2avgpopP = mean(V2avgP,1);
        V2avgpopstdP = std(V2avgP,1);

        dNavgpopP = mean(dNavgP,1);
        dNavgpopstdP = std(dNavgP,1);

        %         dN2avgpopP = mean(dN2avgP,1);
        %         dN2avgpopstdP = std(dN2avgP,1);

        VavgpopM = mean(VavgM,1);
        VavgpopstdM = std(VavgM,1);

        V2avgpopM = mean(V2avgM,1);
        V2avgpopstdM = std(V2avgM,1);

        dNavgpopM = mean(dNavgM,1);
        dNavgpopstdM = std(dNavgM,1);

        %         dN2avgpopM = mean(dN2avgM,1);
        %         dN2avgpopstdM = std(dN2avgM,1);


        % print +icFactor

        % save data

        dirName = ['RandomRegularGraph_trackingEwithnprg_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor)];
        %         if exist(dirName) ~= 7  % if sub-directory does not exist, make it
        %             mkdir(dirName);
        %         end
        if ~exist(dirName,'dir') % if sub-directory does not exist, make it
            mkdir(dirName);
        end

        fname =  ['RandomRegularGraph_trackingEwithnprg_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/Vavgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
        writematrix([(1:Tmax)*dt; VavgpopP]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraph_trackingEwithnprg_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/Vavgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
        writematrix([(1:Tmax)*dt; VavgpopstdP]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraph_trackingEwithnprg_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/dNavgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
        writematrix([(1:Tmax)*dt; dNavgpopP/dt]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraph_trackingEwithnprg_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/dNavgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
        writematrix([(1:Tmax)*dt; dNavgpopstdP/dt]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraph_trackingEwithnprg_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/V2avgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
        writematrix([(1:Tmax)*dt; V2avgpopP]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraph_trackingEwithnprg_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/V2avgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
        writematrix([(1:Tmax)*dt; V2avgpopstdP]',fname,'Delimiter','tab');



        % print -icFactor

        % save data

        dirName = ['RandomRegularGraph_trackingEwithnprg_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_icFactor' num2str(-icFactor)];
        %         if exist(dirName) ~= 7  % if sub-directory does not exist, make it
        %             mkdir(dirName);
        %         end
        if ~exist(dirName,'dir') % if sub-directory does not exist, make it
            mkdir(dirName);
        end

        fname =  ['RandomRegularGraph_trackingEwithnprg_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_icFactor' num2str(-icFactor) '/Vavgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
        writematrix([(1:Tmax)*dt; VavgpopM]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraph_trackingEwithnprg_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_icFactor' num2str(-icFactor) '/Vavgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
        writematrix([(1:Tmax)*dt; VavgpopstdM]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraph_trackingEwithnprg_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_icFactor' num2str(-icFactor) '/dNavgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
        writematrix([(1:Tmax)*dt; dNavgpopM/dt]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraph_trackingEwithnprg_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_icFactor' num2str(-icFactor) '/dNavgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
        writematrix([(1:Tmax)*dt; dNavgpopstdM/dt]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraph_trackingEwithnprg_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_icFactor' num2str(-icFactor) '/V2avgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
        writematrix([(1:Tmax)*dt; V2avgpopM]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraph_trackingEwithnprg_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_icFactor' num2str(-icFactor) '/V2avgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '.txt'];
        writematrix([(1:Tmax)*dt; V2avgpopstdM]',fname,'Delimiter','tab');






    end

end

toc




 

