tic
% Simulation of the stochastic spiking model to test critical point
% hypothesis

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ABSORBING STATE NETWORK
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rng(1) % set rng seed


%%%%%%%%%%%%%%%
% 3d excitatory nearest-neighbor lattice
%%%%%%%%%%%%%%%
J = load('adj_lattice_d3_L14.txt');
N = 14^3;
J = J - eye(N);
saveflag = '3dlattice';

%%%%%%%%%%%%%%%
% Excitatory random regular graph
%%%%%%%%%%%%%%%

% N = 2048;
% numNeighbors = 3;
% % J = full(createRandRegGraph(N,numNeighbors))/sqrt(numNeighbors-1); % normalizes bulk eigs to pm 2, but isolated leading exponent becomes k/sqrt(k-1)
% J = full(createRandRegGraph(N,numNeighbors)); % bulk eigs are +/- 2sqrt(k-1), leading eig is k.
% J = J - eye(N);
% [Vj,Dj] = eig(J);
% saveflag = 'randreg';

%%%%%%%%%%%%%%%
% EI random regular graph, deg = 3
%%%%%%%%%%%%%%%

% N = 2048;
% numNeighbors = 3;
% % J = full(createRandRegGraph(N,numNeighbors))/sqrt(numNeighbors-1); % normalizes bulk eigs to pm 2, but isolated leading exponent becomes k/sqrt(k-1)
% J = full(createRandRegGraph(N,numNeighbors)); % bulk eigs are +/- 2sqrt(k-1), leading eig is k.
% J = J - eye(N);
% J = J - (numNeighbors-2*sqrt(numNeighbors-1))*ones(N)/N; % move outlier to max eig of bulk.
% [Vj,Dj] = eig(J);
% saveflag = 'randregwithinhib';

%%%%%%%%%%%%%%%
% EI random regular graph, deg > 3
%%%%%%%%%%%%%%%

% rng(2) % creates a network with max bulk degree less than 2*sqrt(k-1). rng(1) gives a value slightly larger than this limit.
% 
% N = 2048;
% numNeighbors = 4;
% J = full(createRandRegGraph(N,numNeighbors)); % bulk eigs are +/- 2sqrt(k-1), leading eig is k.
% J = J - eye(N);
% J = J - (numNeighbors-2*sqrt(numNeighbors-1))*ones(N)/N; % move outlier to max eig of bulk.
% [Vj,Dj] = eig(J);

% if max(diag(Dj)) - (2*sqrt(numNeighbors-1)-1) > 1e-10
%     error('Homogeneous mode is not maximum eigenvalue.') 
% end

%%%%%%%%%%%%%%%
% EI configuration model, 90% deg = 3, 10% deg = 4
%%%%%%%%%%%%%%%

% N = 2000;
% Jconfig = load('adj_configmodel_deg3and4_3frac0.9_N2000_seed12.txt'); % no self-loops or multi-edges
% frac = 0.9;
% degs = sum(Jconfig,2); % get degree of each node
% L = Jconfig - diag(degs); % construct (negative of) Laplacian matrix.
% [~,Dl] = eig(L); % get eigenvalues of Laplacian (don't need eigenmodes)
% dlsort = sort(diag(Dl),'ascend');
% J = L + 2.0*eye(N) - (dlsort(end)-dlsort(end-1)-1/N)/N*ones(N); % this matrix will have positive Lambda_max with no outlier
% [~,Dj] = eig(J);
% saveflag = 'randconfigwithinhib';

%%%%%%%%%%%%%%%
% EI configuration model, 80% deg = 3, 20% deg = 4
%%%%%%%%%%%%%%%

% N = 2000;
% Jconfig = load('adj_configmodel_deg3and4_3frac0.8_N2000_seed8.txt'); % no self-loops or multi-edges
% frac = 0.8;
% degs = sum(Jconfig,2); % get degree of each node
% L = Jconfig - diag(degs); % construct (negative of) Laplacian matrix.
% [~,Dl] = eig(L); % get eigenvalues of Laplacian (don't need eigenmodes)
% dlsort = sort(diag(Dl),'ascend');
% J = L + 2.0*eye(N) - (dlsort(end)-dlsort(end-1)-1/N)/N*ones(N); % this matrix will have positive Lambda_max with no outlier
% [~,Dj] = eig(J);
% saveflag = 'randconfigwithinhib';


%%%%%%%%%%%%%

Tmax = 5000; % max number of timesteps
Ntrials = 100; % number of trials to average over


%%

rng(2)

dt = 0.1; % time step

icFactor = 10; % for power law decay estimates

VavgP = zeros(N,Tmax);

dNavgP = zeros(N,Tmax);

% variables for variances
% V2avgP = zeros(N,Tmax);
% dN2avgP= zeros(N,Tmax);


% Parameters - changing J0.
Vth = 0;
Vs = 1.0;
phi0 = 0.5; % for sigmoid
phiprime0 = 0.25/Vs; % for sigmoid

%%%%%%%%%%%%%%
% Lattice network parameters
%%%%%%%%%%%%%%

% d = 3
%J0 = 0.4125; % Jc
%J0 = 0.825; % Jc
%J0 = 1.65; % 2*Jc

%%%%%%%%%%%%%%
% Rand reg, deg = 3
%%%%%%%%%%%%%%

% mean-field: Jc = 4/(2*sqrt(3-1)-1) = 2.187

% J0 = 2.0;
% J0 = 2.1;
% J0 = 2.2;
% J0 = 2.3;
% J0 = 2.4;
% J0 = 2.5;

%J0 = 1.085;
%J0 = 2.17;
%J0 = 4.34;

%%%%%%%%%%%%%%
% Rand reg with EI, deg = 3
%%%%%%%%%%%%%%

% mean-field: Jc = 4/(2*sqrt(3-1)-1) = 2.187

% J0 = 2.0;
% J0 = 2.1;
% J0 = 2.2;
% J0 = 2.3;
% J0 = 2.4;
% J0 = 2.5;

%J0 = 1.16;
%J0 = 2.32;
%J0 = 4.64;

%%%%%%%%%%%%%%
% Rand reg with inhib
%%%%%%%%%%%%%%

%J0 = 4/(2*sqrt(numNeighbors-1)-1); % mean-field

%J0 = 2/(2*sqrt(numNeighbors-1)-1); % Jc/2
% J0 = 8/(2*sqrt(numNeighbors-1)-1); % 2*Jc

%%%%%%%%%%%%%%
% Rand reg with inhib and gap fraction
%%%%%%%%%%%%%%

J0 = 4/(numNeighbors - 1 - gapfrac*(numNeighbors-2*sqrt(numNeighbors-1))); % mean-field

%J0 = 2/(2*sqrt(numNeighbors-1)-1); % Jc/2
% J0 = 8/(2*sqrt(numNeighbors-1)-1); % 2*Jc

%%%%%%%%%%%%%%
% EI config model 90% deg 3, 10% deg 4
%%%%%%%%%%%%%%

% mean-field: Jc = 4/Dj(end,end) = 2.2264
%Jcest = 2.2;

%J0 = 1.1;
%J0 = 1.9;
%J0 = 2.0; 
%J0 = 2.1;
%J0 = 2.2;
%J0 = 2.3;
%J0 = 2.4;
%J0 = 2.5;
%J0 = 4.4;

%%%%%%%%%%%%%%
% EI config model 80% deg 3, 20% deg 4
%%%%%%%%%%%%%%

% mean-field: Jc = 4/Dj(end,end) = 2.2635
%Jcest = 1.98;%

%J0 = 1.98/2;
%J0 = 1.98;
%J0 = 2*1.98;

%J0 = 1.8;
%J0 = 1.9;
%J0 = 2.0; 
%J0 = 2.1;
%J0 = 2.2;
%J0 = 2.3;
%J0 = 2.4;
%J0 = 2.5;

%%%%%%%%%%%%%%%%

Jself = 0.0; % -1 for soft refractory effect
offset = 0.0; % background firing rate offset
taumem = 1.0;
Eleak = 0;



%%

for h=1:Ntrials
    
rng(1)
    
VP = zeros(N,Tmax);
VP(:,1) = icFactor;

% change seed to change spiking activity
rng(ceil(J0)*(1+h))

dNP = zeros(N,Tmax);

for t=2:Tmax
    
    dNP(:,t) = poissrnd(dt*max(0,-0.5+1./(1+exp(-(VP(:,t-1)-Vth)/Vs)))); % sigmoid with offset
   
    
    VP(:,t) = VP(:,t-1) + dt/taumem*(-VP(:,t-1) + Eleak) + (J0*J+Jself*eye(N))*dNP(:,t)/taumem;
    
    
end

VavgP = VavgP + VP;

dNavgP = dNavgP + dNP;

% unused variables for variances
% V2avgP = V2avgP + VP.^2;
% dN2avgP = dN2avgP + dNP.^2;



end

VavgP = VavgP/Ntrials;

dNavgP = dNavgP/Ntrials;

% unused variables for variances
% V2avgP = V2avgP/Ntrials - VavgP.^2;
% dN2avgP = dN2avgP/Ntrials - dNavgP.^2;
 
toc

% Compute population averages
avgrateP = mean(dNavgP,1)/dt;
avgVP = mean(VavgP,1);

%% save data

if strcmp(saveflag,'3dlattice')
     fname =  ['Lattice_absorbing_nonlinsweep_d' num2str(d) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
elseif strcmp(saveflag,'randreg')
    fname =  ['RandomRegularGraph_absorbing_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
elseif strcmp(saveflag,'randregwithinhib')
    fname =  ['RandomRegularGraphwithInhib_absorbing_nonlinsweep_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0)   '.txt'];
elseif strcmp(saveflag,'randconfigwithinhib') 
    fname =  ['RandConfigwithInhib_deg3and4_absorbing_nonlinsweep_Ntrials' num2str(Ntrials) '_N'  num2str(N) '_Tmax' num2str(Tmax) '_J'  num2str(J0) '_frac' num2str(frac)   '.txt'];
end

writematrix([avgVP; avgrateP]',fname,'Delimiter','tab');
