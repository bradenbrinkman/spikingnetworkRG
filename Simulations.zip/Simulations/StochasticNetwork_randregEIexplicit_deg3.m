
% Simulation of the stochastic spiking model to test critical point
% hypothesis
tic
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SPONTANEOUS NETWORK
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rng(1) % set rng seed


%%%%%%%%%%%%%%%
% EI random regular graph
%%%%%%%%%%%%%%%

NE = 2048; %2^11
numNeighbors = 3;
J = full(createRandRegGraph(NE,numNeighbors)); % bulk eigs are +/- 2sqrt(k-1), leading eig is k.
J = J - eye(NE);
%J = J - (numNeighbors-2*sqrt(numNeighbors-1))*ones(N)/N; % move outlier to max eig of bulk. % this will be done using explicit Inhib pop
[Vj,Dj] = eig(J);

NI = 2^9; % NI/NE = 25%

Tmax = 5e3; % need to go to longer times because
Ntrials = 5;

% For faster sims
% Tmax = 10000;
% Ntrials = 10;

% % More timepoints
% Tmax = 100000; % max number of timesteps
% Ntrials = 10;

% % More timepoints and trials
% Tmax = 100000; % max number of timesteps
% Ntrials = 100;


%%

rng(2)

dt = 0.01; % time step
%dt = 0.001; % time step

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Big sweep to estimate Ec(J) using rand reg network with inhib as guide. No clear transition again.
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Jcrit = 6.0; % central value of J to sweep around

dJ = 0.25;  % increment

Jstart = -6*dJ; 
Jend = 6*dJ;

J0vals = Jcrit + (Jstart:dJ:Jend); % note: different from the lattices!

dE = 0.05; % increment of leak value to sweep over

Estart = -9*dE;
Eend = 9*dE;

Ecrit  = -4.5*ones(size(J0vals));
% 
% % took about 2 hours to run (both +/-) for Tmax = 1e3
% % took 5 hours for Tmax = 5e3, Ntrials = 5
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Eleakdiffs = (1+ (Estart:(dE):Eend));

Eleakvals = Ecrit'*Eleakdiffs;

icFactor = 10; % for power law decay estimates

VEavgP = zeros(NE,Tmax);

VE2avgP = zeros(NE,Tmax);

dNEavgP = zeros(NE,Tmax);

dNE2avgP= zeros(NE,Tmax);

VIavgP = zeros(NI,Tmax);

VI2avgP = zeros(NI,Tmax);

dNIavgP = zeros(NI,Tmax);

dNI2avgP= zeros(NI,Tmax);

sIavgP = zeros(NI,Tmax);

sI2avgP= zeros(NI,Tmax);




% Excitatory Parameters
VthE = 0;
VsE = 1.0;

taumem = 1.0;

Eleak = 0;

JIE = 2*(numNeighbors-2*sqrt(numNeighbors-1));

% Inhibitory Parameters.
VthI = -1.0;
JEI = -0.05*JIE;
JII = -0.05*JIE;
gammaI = -1/JII;
% JII = -0.0;
% gammaI = -1/JEI;
taumemI = 0.1;
tausynI = 2.0; % needs to be smaller than taumem but larger than dt
%EleakI = 0; %VthI;
EleakI = VthI; %


%%

Jloops = numel(J0vals);
Eloops = numel(Eleakdiffs);

parfor jj = 1:Jloops

    J0 = J0vals(jj);

    for ee=1:Eloops


        Eleak = Ecrit(jj)*(1+ Estart + dE*(ee-1)); % to avoid broadcasting issue

        % reset average variables

        VEavgP = zeros(NE,Tmax);
        VE2avgP = zeros(NE,Tmax);
        dNEavgP = zeros(NE,Tmax);
        dNE2avgP= zeros(NE,Tmax);
        sEavgP = zeros(NE,Tmax);
        sE2avgP= zeros(NE,Tmax);
        VIavgP = zeros(NI,Tmax);
        VI2avgP = zeros(NI,Tmax);
        dNIavgP = zeros(NI,Tmax);
        dNI2avgP= zeros(NI,Tmax);
        sIavgP = zeros(NI,Tmax);
        sI2avgP= zeros(NI,Tmax);


        VEavgM = zeros(NE,Tmax);
        VE2avgM = zeros(NE,Tmax);
        dNEavgM = zeros(NE,Tmax);
        dNE2avgM= zeros(NE,Tmax);
        sEavgM = zeros(NE,Tmax);
        sE2avgM= zeros(NE,Tmax);
        VIavgM = zeros(NI,Tmax);
        VI2avgM = zeros(NI,Tmax);
        dNIavgM = zeros(NI,Tmax);
        dNI2avgM= zeros(NI,Tmax);
        sIavgM = zeros(NI,Tmax);
        sI2avgM= zeros(NI,Tmax);


        for h=1:Ntrials

            rng(1)

            VEP = zeros(NE,Tmax);
            VEP(:,1) = icFactor;
            VIP = zeros(NI,Tmax);

            VEM = zeros(NE,Tmax);
            VEM(:,1) = -icFactor;
            VIM = zeros(NI,Tmax);

            % change seed to change spiking activity
            rng(ceil(J0)*(1+h)+2025) % for set 2

            dNEP = zeros(NE,Tmax);
            dNIP = zeros(NI,Tmax);
            sIP = zeros(NI,Tmax);

            dNEM = zeros(NE,Tmax);
            dNIM = zeros(NI,Tmax);
            sIM = zeros(NI,Tmax);

            for t=2:Tmax

                % % +icFactor

                % Excitatory neurons
                dNEP(:,t) = poissrnd(dt./(1+exp(-(VEP(:,t-1)-VthE)/VsE))); % sigmoid with offset
                VEP(:,t) = VEP(:,t-1) + dt/taumem*(-VEP(:,t-1) + Eleak) + ((J0*J)*dNEP(:,t)+J0*JEI/NI*sum(sIP(:,t-1)))/taumem;

                % Inhibitory neurons
                dNIP(:,t) = poissrnd(dt*gammaI/J0*max(0,VIP(:,t-1)-VthI));
                VIP(:,t) = VIP(:,t-1) + dt/taumemI*(-VIP(:,t-1) + EleakI) + (J0*JIE/NE*sum(dNEP(:,t))+J0*JII/NI*sum(sIP(:,t-1)))/taumemI;
                sIP(:,t) = (1-dt/tausynI)*sIP(:,t-1) + dNIP(:,t)/tausynI;

                % % -icFactor

                % Excitatory neurons
                dNEM(:,t) = poissrnd(dt./(1+exp(-(VEM(:,t-1)-VthE)/VsE))); % sigmoid with offset
                VEM(:,t) = VEM(:,t-1) + dt/taumem*(-VEM(:,t-1) + Eleak) + ((J0*J)*dNEM(:,t)+J0*JEI/NI*sum(sIM(:,t-1)))/taumem;

                % Inhibitory neurons
                dNIM(:,t) = poissrnd(dt*gammaI/J0*max(0,VIM(:,t-1)-VthI));
                VIM(:,t) = VIM(:,t-1) + dt/taumemI*(-VIM(:,t-1) + EleakI) + (J0*JIE/NE*sum(dNEM(:,t))+J0*JII/NI*sum(sIM(:,t-1)))/taumemI;
                sIM(:,t) = (1-dt/tausynI)*sIM(:,t-1) + dNIM(:,t)/tausynI;

            end

            VEavgP = VEavgP + VEP;
            VE2avgP = VE2avgP + VEP.^2;
            dNEavgP = dNEavgP + dNEP;
            dNE2avgP = dNE2avgP + dNEP.^2;
            VIavgP = VIavgP + VIP;
            VI2avgP = VI2avgP + VIP.^2;
            dNIavgP = dNIavgP + dNIP;
            dNI2avgP = dNI2avgP + dNIP.^2;
            sIavgP = sIavgP + sIP;
            sI2avgP = sI2avgP + sIP.^2;

            VEavgM = VEavgM + VEM;
            VE2avgM = VE2avgM + VEM.^2;
            dNEavgM = dNEavgM + dNEM;
            dNE2avgM = dNE2avgM + dNEM.^2;
            VIavgM = VIavgM + VIM;
            VI2avgM = VI2avgM + VIM.^2;
            dNIavgM = dNIavgM + dNIM;
            dNI2avgM = dNI2avgM + dNIM.^2;
            sIavgM = sIavgM + sIM;
            sI2avgM = sI2avgM + sIM.^2;


        end

        VEavgP = VEavgP/Ntrials;
        dNEavgP = dNEavgP/Ntrials;
        VE2avgP = VE2avgP/Ntrials - VEavgP.^2;
        dNE2avgP = dNE2avgP/Ntrials - dNEavgP.^2;
        VIavgP = VIavgP/Ntrials;
        dNIavgP = dNIavgP/Ntrials;
        sIavgP = sIavgP/Ntrials;
        VI2avgP = VI2avgP/Ntrials - VIavgP.^2;
        dNI2avgP = dNI2avgP/Ntrials - dNIavgP.^2;
        sI2avgP = sI2avgP/Ntrials - sIavgP.^2;


        VEavgM = VEavgM/Ntrials;
        dNEavgM = dNEavgM/Ntrials;
        VE2avgM = VE2avgM/Ntrials - VEavgM.^2;
        dNE2avgM = dNE2avgM/Ntrials - dNEavgM.^2;
        VIavgM = VIavgM/Ntrials;
        dNIavgM = dNIavgM/Ntrials;
        sIavgM = sIavgM/Ntrials;
        VI2avgM = VI2avgM/Ntrials - VIavgM.^2;
        dNI2avgM = dNI2avgM/Ntrials - dNIavgM.^2;
        sI2avgM = sI2avgM/Ntrials - sIavgM.^2;


        % calculate population averages and print:

        % Exc. + pos
        VEavgpopP = mean(VEavgP,1);
        VEavgpopstdP = std(VEavgP,1);

        VE2avgpopP = mean(VE2avgP,1);
        VE2avgpopstdP = std(VE2avgP,1);

        dNEavgpopP = mean(dNEavgP,1);
        dNEavgpopstdP = std(dNEavgP,1);

        %         dNE2avgpopP = mean(dNE2avgP,1);
        %         dNE2avgpopstdP = std(dNE2avgP,1);

        % Inhib + pos.

        VIavgpopP = mean(VIavgP,1);
        VIavgpopstdP = std(VIavgP,1);

        VI2avgpopP = mean(VI2avgP,1);
        VI2avgpopstdP = std(VI2avgP,1);

        dNIavgpopP = mean(dNIavgP,1);
        dNIavgpopstdP = std(dNIavgP,1);

        %         dNI2avgpopP = mean(dNI2avgP,1);
        %         dNI2avgpopstdP = std(dNI2avgP,1);

        % Exc. + min.

        VEavgpopM = mean(VEavgM,1);
        VEavgpopstdM = std(VEavgM,1);

        VE2avgpopM = mean(VE2avgM,1);
        VE2avgpopstdM = std(VE2avgM,1);

        dNEavgpopM = mean(dNEavgM,1);
        dNEavgpopstdM = std(dNEavgM,1);

        %         dNE2avgpopM = mean(dNE2avgM,1);
        %         dNE2avgpopstdM = std(dNE2avgM,1);

        % Inhib + min.

        VIavgpopM = mean(VIavgM,1);
        VIavgpopstdM = std(VIavgM,1);

        VI2avgpopM = mean(VI2avgM,1);
        VI2avgpopstdM = std(VI2avgM,1);

        dNIavgpopM = mean(dNIavgM,1);
        dNIavgpopstdM = std(dNIavgM,1);

        %         dNI2avgpopM = mean(dNI2avgM,1);
        %         dNI2avgpopstdM = std(dNI2avgM,1);


        % print +icFactor

        % save data

        dirName = ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor)];
        %         if exist(dirName) ~= 7  % if sub-directory does not exist, make it
        %             mkdir(dirName);
        %         end
        if ~exist(dirName,'dir') % if sub-directory does not exist, make it
            mkdir(dirName);
        end

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VEPavgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VEavgpopP]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VEPavgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VEavgpopstdP]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/dNEPavgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; dNEavgpopP/dt]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/dNEPavgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; dNEavgpopstdP/dt]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VEP2avgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VE2avgpopP]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VEP2avgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VE2avgpopstdP]',fname,'Delimiter','tab');

        % inhib
        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VIPavgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VIavgpopP]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VIPavgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VIavgpopstdP]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/dNIPavgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; dNIavgpopP/dt]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/dNIPavgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; dNIavgpopstdP/dt]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VIP2avgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VI2avgpopP]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VIP2avgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VI2avgpopstdP]',fname,'Delimiter','tab');



        % print -icFactor

        % save data

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VEMavgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VEavgpopM]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VEMavgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VEavgpopstdM]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/dNEMavgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; dNEavgpopM/dt]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/dNEMavgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; dNEavgpopstdM/dt]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VEM2avgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VE2avgpopM]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VEM2avgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VE2avgpopstdM]',fname,'Delimiter','tab');

        % inhib
        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VIMavgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VIavgpopM]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VIMavgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VIavgpopstdM]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/dNIMavgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; dNIavgpopM/dt]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/dNIMavgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; dNIavgpopstdM/dt]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VIM2avgpop_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VI2avgpopM]',fname,'Delimiter','tab');

        fname =  ['RandomRegularGraphEIExplicit_spontaneous_deg' num2str(numNeighbors) '_Ntrials' num2str(Ntrials) '_NE'  num2str(NE) '_NI'  num2str(NI) '_Tmax' num2str(Tmax) '_icFactor' num2str(icFactor) '/VIM2avgpopstd_J'  num2str(J0)   '_Eleak'  num2str(Eleak)   '_set2.txt'];
        writematrix([(1:Tmax)*dt; VI2avgpopstdM]',fname,'Delimiter','tab');


    end

end



%%

toc

